<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* graphql/graphiql */
class __TwigTemplate_882577d34dd95101bc85ac890ed83e1c940eb6ca4243a844175f5e478e137110 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/basecp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/graphiql");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Explore the GraphQL API");
        // line 3
        $context["selectedSubnavItem"] = "explore";
        // line 4
        $context["showHeader"] = false;
        // line 1
        $this->parent = $this->loadTemplate("_layouts/basecp", "graphql/graphiql", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/graphiql");
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "body");
        // line 7
        echo "    <div dir=\"ltr\" endpoint=\"";
        echo twig_escape_filter($this->env, (isset($context["url"]) || array_key_exists("url", $context) ? $context["url"] : (function () { throw new RuntimeError('Variable "url" does not exist.', 7, $this->source); })()), "html", null, true);
        echo "\" id=\"graphiql\" schemas=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["schemas"]) || array_key_exists("schemas", $context) ? $context["schemas"] : (function () { throw new RuntimeError('Variable "schemas" does not exist.', 7, $this->source); })())), "html", null, true);
        echo "\" selectedSchema=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(["name" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["selectedSchema"]) || array_key_exists("selectedSchema", $context) ? $context["selectedSchema"] : (function () { throw new RuntimeError('Variable "selectedSchema" does not exist.', 7, $this->source); })()), "name", []), "schema" => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["selectedSchema"]) || array_key_exists("selectedSchema", $context) ? $context["selectedSchema"] : (function () { throw new RuntimeError('Variable "selectedSchema" does not exist.', 7, $this->source); })()), "uid", [])]), "html", null, true);
        echo "\">
        <div class=\"spinner big\"></div>
    </div>
";
        craft\helpers\Template::endProfile("block", "body");
    }

    public function getTemplateName()
    {
        return "graphql/graphiql";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 7,  55 => 6,  49 => 1,  47 => 4,  45 => 3,  43 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/basecp\" %}
{% set title = \"Explore the GraphQL API\"|t %}
{% set selectedSubnavItem = 'explore' %}
{% set showHeader = false %}

{% block body %}
    <div dir=\"ltr\" endpoint=\"{{ url }}\" id=\"graphiql\" schemas=\"{{ schemas|json_encode}}\" selectedSchema=\"{{ {name: selectedSchema.name, schema: selectedSchema.uid, }|json_encode }}\">
        <div class=\"spinner big\"></div>
    </div>
{% endblock %}
", "graphql/graphiql", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/graphql/graphiql.twig");
    }
}
