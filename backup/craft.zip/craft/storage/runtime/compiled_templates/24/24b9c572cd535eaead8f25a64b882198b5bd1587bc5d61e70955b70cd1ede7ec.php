<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/toolbar */
class __TwigTemplate_c25ebfa1d213e3c3d6fc97ddae9790c7149ae2635d5ec8381776ad19a58cdc2d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/toolbar");
        // line 1
        $macros["__internal_parse_3"] = $this->macros["__internal_parse_3"] = $this->loadTemplate("_includes/forms", "_elements/toolbar", 1)->unwrap();
        // line 6
        echo "
";
        // line 7
        $macros["__internal_parse_4"] = $this->macros["__internal_parse_4"] = $this;
        // line 8
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 8, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Sort by {attribute}", 1 => "Score", 2 => "Structure", 3 => "Display in a table", 4 => "Display hierarchically", 5 => "Display as thumbnails"]], "method");
        // line 16
        echo "
";
        // line 17
        $context["elementInstance"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "app", []), "elements", []), "createElement", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 17, $this->source); })())], "method");
        // line 18
        $context["context"] = ((array_key_exists("context", $context)) ? ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 18, $this->source); })())) : ("index"));
        // line 19
        $context["showStatusMenu"] = (((array_key_exists("showStatusMenu", $context) && ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 19, $this->source); })()) != "auto"))) ? ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 19, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 19, $this->source); })()), "hasStatuses", [], "method")));
        // line 20
        $context["showSiteMenu"] = ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 20, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) ? ((($context["showSiteMenu"]) ?? ("auto"))) : (false));
        // line 21
        if (((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 21, $this->source); })()) == "auto")) {
            // line 22
            echo "    ";
            $context["showSiteMenu"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 22, $this->source); })()), "isLocalized", [], "method");
        }
        // line 24
        $context["sortOptions"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 24, $this->source); })()), "sortOptions", [], "method");
        // line 25
        $context["idPrefix"] = (("elementtoolbar" . twig_random($this->env)) . "-");
        // line 26
        echo "
";
        // line 27
        if (((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 27, $this->source); })()) || ((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 27, $this->source); })()) == "index"))) {
            // line 28
            echo "    <div>
        <label id=\"";
            // line 29
            echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 29, $this->source); })()), "html", null, true);
            echo "status-label\" class=\"visually-hidden\">";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Status", "app"), "html", null, true);
            echo "</label>
        <button id=\"";
            // line 30
            echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 30, $this->source); })()), "html", null, true);
            echo "status-button\" aria-labelledby=\"";
            echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 30, $this->source); })()), "html", null, true);
            echo "status-label\" type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("All", "app"), "html", null, true);
            echo "</a></li>
                ";
            // line 34
            if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 34, $this->source); })())) {
                // line 35
                echo "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["elementInstance"]) || array_key_exists("elementInstance", $context) ? $context["elementInstance"] : (function () { throw new RuntimeError('Variable "elementInstance" does not exist.', 35, $this->source); })()), "statuses", [], "method"));
                foreach ($context['_seq'] as $context["status"] => $context["info"]) {
                    // line 36
                    echo "                        ";
                    $context["label"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "label", [])) : ($context["info"]));
                    // line 37
                    echo "                        ";
                    $context["color"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["info"], "color", [])) : (""));
                    // line 38
                    echo "                        <li><a data-status=\"";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo "\"><span class=\"status ";
                    echo twig_escape_filter($this->env, $context["status"], "html", null, true);
                    echo " ";
                    echo twig_escape_filter($this->env, (isset($context["color"]) || array_key_exists("color", $context) ? $context["color"] : (function () { throw new RuntimeError('Variable "color" does not exist.', 38, $this->source); })()), "html", null, true);
                    echo "\"></span>";
                    echo twig_escape_filter($this->env, (isset($context["label"]) || array_key_exists("label", $context) ? $context["label"] : (function () { throw new RuntimeError('Variable "label" does not exist.', 38, $this->source); })()), "html", null, true);
                    echo "</a></li>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['status'], $context['info'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 40
                echo "                ";
            }
            // line 41
            echo "            </ul>
            ";
            // line 42
            if (((isset($context["context"]) || array_key_exists("context", $context) ? $context["context"] : (function () { throw new RuntimeError('Variable "context" does not exist.', 42, $this->source); })()) == "index")) {
                // line 43
                echo "                ";
                if ((isset($context["showStatusMenu"]) || array_key_exists("showStatusMenu", $context) ? $context["showStatusMenu"] : (function () { throw new RuntimeError('Variable "showStatusMenu" does not exist.', 43, $this->source); })())) {
                    echo "<hr class=\"padded\">";
                }
                // line 44
                echo "                <ul class=\"padded\">
                    ";
                // line 45
                if ((($context["canHaveDrafts"]) ?? (false))) {
                    // line 46
                    echo "                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Drafts", "app"), "html", null, true);
                    echo "</a></li>
                    ";
                }
                // line 48
                echo "                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Trashed", "app"), "html", null, true);
                echo "</a></li>
                </ul>
            ";
            }
            // line 51
            echo "        </div>
    </div>
";
        }
        // line 54
        if ((isset($context["showSiteMenu"]) || array_key_exists("showSiteMenu", $context) ? $context["showSiteMenu"] : (function () { throw new RuntimeError('Variable "showSiteMenu" does not exist.', 54, $this->source); })())) {
            // line 55
            echo "    ";
            $this->loadTemplate("_elements/sitemenu", "_elements/toolbar", 55)->display($context);
        }
        // line 57
        echo "<div class=\"flex-grow texticon search icon has-filter-btn\">
    ";
        // line 58
        echo twig_call_macro($macros["__internal_parse_3"], "macro_text", [["class" => "clearable", "placeholder" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app"), "inputAttributes" => ["aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Search", "app")]]]], 58, $context, $this->getSourceContext());
        // line 66
        echo "
    ";
        // line 67
        echo $this->extensions['craft\web\twig\Extension']->tagFunction("button", ["role" => "button", "class" => "clear-btn hidden", "title" => $this->extensions['craft\web\twig\Extension']->translateFilter("Clear search", "app"), "aria" => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Clear search", "app")]]);
        // line 74
        echo "
    <button class=\"filter-btn\" title=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Filter results", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Filter results", "app"), "html", null, true);
        echo "\" aria-expanded=\"false\"></button>
</div>
<div>
    <label id=\"";
        // line 78
        echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 78, $this->source); })()), "html", null, true);
        echo "sort-by-label\" class=\"visually-hidden\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sort by", "app"), "html", null, true);
        echo "</label>
    <button id=\"";
        // line 79
        echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 79, $this->source); })()), "html", null, true);
        echo "sort-by-btn\" aria-labelledby=\"";
        echo twig_escape_filter($this->env, (isset($context["idPrefix"]) || array_key_exists("idPrefix", $context) ? $context["idPrefix"] : (function () { throw new RuntimeError('Variable "idPrefix" does not exist.', 79, $this->source); })()), "html", null, true);
        echo "sort-by-label\" type=\"button\" class=\"btn menubtn sortmenubtn\" ";
        if ((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 79, $this->source); })())) {
            echo " title=\"";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sort by {attribute}", "app", ["attribute" => twig_call_macro($macros["__internal_parse_4"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 79, $this->source); })()))], 79, $context, $this->getSourceContext())]), "html", null, true);
            echo "\"";
        }
        echo " data-icon=\"asc\">";
        echo (((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 79, $this->source); })())) ? (twig_call_macro($macros["__internal_parse_4"], "macro_sortOptionLabel", [twig_first($this->env, (isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 79, $this->source); })()))], 79, $context, $this->getSourceContext())) : (""));
        echo "</button>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            ";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sortOptions"]) || array_key_exists("sortOptions", $context) ? $context["sortOptions"] : (function () { throw new RuntimeError('Variable "sortOptions" does not exist.', 82, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["sortOption"]) {
            // line 83
            echo "                <li>
                    ";
            // line 84
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["class" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 85
$context["loop"], "first", [])) ? ("sel") : ("")), "text" => twig_call_macro($macros["__internal_parse_4"], "macro_sortOptionLabel", [            // line 86
$context["sortOption"]], 86, $context, $this->getSourceContext()), "data" => ["attr" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 88
$context["sortOption"], "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "attribute", [])) : ((((craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "orderBy", [])) : ($context["key"])))), "default-dir" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 89
$context["sortOption"], "defaultDir", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "defaultDir", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["sortOption"], "defaultDir", [])) : (false))]]);
            // line 91
            echo "
                </li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['key'], $context['sortOption'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 94
        echo "        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">";
        // line 97
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Ascending", "app"), "html", null, true);
        echo "</a></li>
            <li><a data-dir=\"desc\">";
        // line 98
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Descending", "app"), "html", null, true);
        echo "</a></li>
        </ul>
    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "_elements/toolbar");
    }

    // line 3
    public function macro_sortOptionLabel($__sortOption__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "sortOption" => $__sortOption__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sortOptionLabel");
            // line 4
            echo "    ";
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["sortOption"] ?? null), "label", [])) : ((isset($context["sortOption"]) || array_key_exists("sortOption", $context) ? $context["sortOption"] : (function () { throw new RuntimeError('Variable "sortOption" does not exist.', 4, $this->source); })()))), "html", null, true);
            echo "
";
            craft\helpers\Template::endProfile("macro", "sortOptionLabel");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/toolbar";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  284 => 4,  270 => 3,  260 => 98,  256 => 97,  251 => 94,  235 => 91,  233 => 89,  232 => 88,  231 => 86,  230 => 85,  229 => 84,  226 => 83,  209 => 82,  193 => 79,  187 => 78,  179 => 75,  176 => 74,  174 => 67,  171 => 66,  169 => 58,  166 => 57,  162 => 55,  160 => 54,  155 => 51,  148 => 48,  142 => 46,  140 => 45,  137 => 44,  132 => 43,  130 => 42,  127 => 41,  124 => 40,  109 => 38,  106 => 37,  103 => 36,  98 => 35,  96 => 34,  92 => 33,  82 => 30,  76 => 29,  73 => 28,  71 => 27,  68 => 26,  66 => 25,  64 => 24,  60 => 22,  58 => 21,  56 => 20,  54 => 19,  52 => 18,  50 => 17,  47 => 16,  45 => 8,  43 => 7,  40 => 6,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% from \"_includes/forms\" import text -%}

{% macro sortOptionLabel(sortOption) %}
    {{ sortOption.label ?? sortOption }}
{% endmacro %}

{% from _self import sortOptionLabel %}
{% do view.registerTranslations('app', [
    \"Sort by {attribute}\",
    \"Score\",
    \"Structure\",
    \"Display in a table\",
    \"Display hierarchically\",
    \"Display as thumbnails\",
]) %}

{% set elementInstance = craft.app.elements.createElement(elementType) %}
{% set context = context is defined ? context : 'index' %}
{% set showStatusMenu = (showStatusMenu is defined and showStatusMenu != 'auto' ? showStatusMenu : elementInstance.hasStatuses()) %}
{% set showSiteMenu = (craft.app.getIsMultiSite() ? (showSiteMenu ?? 'auto') : false) %}
{% if showSiteMenu == 'auto' %}
    {% set showSiteMenu = elementInstance.isLocalized() %}
{% endif %}
{% set sortOptions = elementInstance.sortOptions() %}
{% set idPrefix = \"elementtoolbar#{random()}-\" %}

{% if showStatusMenu or context == 'index' %}
    <div>
        <label id=\"{{ idPrefix }}status-label\" class=\"visually-hidden\">{{ \"Status\"|t('app') }}</label>
        <button id=\"{{ idPrefix }}status-button\" aria-labelledby=\"{{ idPrefix }}status-label\" type=\"button\" class=\"btn menubtn statusmenubtn\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</button>
        <div class=\"menu\">
            <ul class=\"padded\">
                <li><a data-status=\"\" class=\"sel\"><span class=\"status\"></span>{{ \"All\"|t('app') }}</a></li>
                {% if showStatusMenu %}
                    {% for status, info in elementInstance.statuses() %}
                        {% set label = info.label ?? info %}
                        {% set color = info.color ?? '' %}
                        <li><a data-status=\"{{ status }}\"><span class=\"status {{ status }} {{ color }}\"></span>{{ label }}</a></li>
                    {% endfor %}
                {% endif %}
            </ul>
            {% if context == 'index' %}
                {% if showStatusMenu %}<hr class=\"padded\">{% endif %}
                <ul class=\"padded\">
                    {% if canHaveDrafts ?? false %}
                        <li><a data-drafts><span class=\"icon\" data-icon=\"draft\" aria-hidden=\"true\"></span>{{ 'Drafts'|t('app') }}</a></li>
                    {% endif %}
                    <li><a data-trashed><span class=\"icon\" data-icon=\"trash\" aria-hidden=\"true\"></span>{{ \"Trashed\"|t('app') }}</a></li>
                </ul>
            {% endif %}
        </div>
    </div>
{% endif %}
{% if showSiteMenu %}
    {% include \"_elements/sitemenu\" %}
{% endif %}
<div class=\"flex-grow texticon search icon has-filter-btn\">
    {{ text({
        class: 'clearable',
        placeholder: \"Search\"|t('app'),
        inputAttributes: {
            aria: {
                label: 'Search'|t('app'),
            },
        },
    }) }}
    {{ tag('button', {
        role: 'button',
        class: 'clear-btn hidden',
        title: 'Clear search'|t('app'),
        aria: {
            label: 'Clear search'|t('app'),
        },
    }) }}
    <button class=\"filter-btn\" title=\"{{ 'Filter results'|t('app') }}\" aria-label=\"{{ 'Filter results'|t('app') }}\" aria-expanded=\"false\"></button>
</div>
<div>
    <label id=\"{{ idPrefix }}sort-by-label\" class=\"visually-hidden\">{{ 'Sort by'|t('app') }}</label>
    <button id=\"{{ idPrefix }}sort-by-btn\" aria-labelledby=\"{{ idPrefix }}sort-by-label\" type=\"button\" class=\"btn menubtn sortmenubtn\" {% if sortOptions %} title=\"{{ 'Sort by {attribute}'|t('app', { attribute: sortOptionLabel(sortOptions|first) }) }}\"{% endif %} data-icon=\"asc\">{{ sortOptions ? sortOptionLabel(sortOptions|first) }}</button>
    <div class=\"menu\">
        <ul class=\"padded sort-attributes\">
            {% for key, sortOption in sortOptions %}
                <li>
                    {{ tag('a', {
                        class: loop.first ? 'sel',
                        text: sortOptionLabel(sortOption),
                        data: {
                            attr: sortOption.attribute ?? sortOption.orderBy ?? key,
                            'default-dir': sortOption.defaultDir ?? false,
                        }
                    }) }}
                </li>
            {% endfor %}
        </ul>
        <hr>
        <ul class=\"padded sort-directions\">
            <li><a data-dir=\"asc\" class=\"sel\">{{ \"Ascending\"|t('app') }}</a></li>
            <li><a data-dir=\"desc\">{{ \"Descending\"|t('app') }}</a></li>
        </ul>
    </div>
</div>
", "_elements/toolbar", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_elements/toolbar.twig");
    }
}
