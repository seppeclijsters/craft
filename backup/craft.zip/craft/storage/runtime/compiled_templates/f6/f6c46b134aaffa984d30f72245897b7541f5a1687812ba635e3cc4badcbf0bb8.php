<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__aa8355eeb839b11313e28a6dc03af47f4109bba2606e8993b482562573f8b0df */
class __TwigTemplate_e6835ef56df6b6d9b3c479e28eca290f9b0429a409b63cd97543b00f140e2a5c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__aa8355eeb839b11313e28a6dc03af47f4109bba2606e8993b482562573f8b0df");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "site", []), "creator", []), "computedType", []);
        craft\helpers\Template::endProfile("template", "__string_template__aa8355eeb839b11313e28a6dc03af47f4109bba2606e8993b482562573f8b0df");
    }

    public function getTemplateName()
    {
        return "__string_template__aa8355eeb839b11313e28a6dc03af47f4109bba2606e8993b482562573f8b0df";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.site.creator.computedType }}", "__string_template__aa8355eeb839b11313e28a6dc03af47f4109bba2606e8993b482562573f8b0df", "");
    }
}
