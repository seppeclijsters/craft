<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* graphql/schemas/_index */
class __TwigTemplate_683fd84457e217ba79797cf4e7bd4d1a52c02396b1c98293d7a33ff68ec200b4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/schemas/_index");
        // line 2
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Schemas", "app");
        // line 4
        if (\Craft::$app->getEdition() < (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 4, $this->source); })()))
        {
            throw new yii\web\NotFoundHttpException;
        }
        // line 6
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 6, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\admintable\\AdminTableAsset"], "method");
        // line 8
        $context["selectedSubnavItem"] = "schemas";
        // line 18
        $context["tableData"] = [];
        // line 19
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 19, $this->source); })()), "app", []), "gql", []), "schemas", []));
        foreach ($context['_seq'] as $context["_key"] => $context["schema"]) {
            // line 20
            $context["tableData"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 20, $this->source); })()), [0 => ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 21
$context["schema"], "id", []), "title" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 22
$context["schema"], "isPublic", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Public Schema", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["schema"], "name", []), "site"))), "url" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 23
$context["schema"], "isPublic", [])) ? (craft\helpers\UrlHelper::url("graphql/schemas/public")) : (craft\helpers\UrlHelper::url(("graphql/schemas/" . craft\helpers\Template::attribute($this->env, $this->source, $context["schema"], "id", []))))), "_showDelete" =>  !craft\helpers\Template::attribute($this->env, $this->source,             // line 24
$context["schema"], "isPublic", [])]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['schema'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 28
        ob_start();
        // line 29
        echo "var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#schemas-vue-admin-table',
    deleteAction: 'graphql/delete-schema',
    tableData: ";
        // line 37
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["tableData"]) || array_key_exists("tableData", $context) ? $context["tableData"] : (function () { throw new RuntimeError('Variable "tableData" does not exist.', 37, $this->source); })()));
        echo "
});
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/schemas/_index", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/schemas/_index");
    }

    // line 10
    public function block_actionButton($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "actionButton");
        // line 11
        echo "    <a class=\"btn submit add icon\" href=\"";
        echo twig_escape_filter($this->env, craft\helpers\UrlHelper::url("graphql/schemas/new"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("New schema", "app"), "html", null, true);
        echo "</a>
";
        craft\helpers\Template::endProfile("block", "actionButton");
    }

    // line 14
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 15
        echo "    <div id=\"schemas-vue-admin-table\"></div>
";
        craft\helpers\Template::endProfile("block", "content");
    }

    public function getTemplateName()
    {
        return "graphql/schemas/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  115 => 15,  110 => 14,  100 => 11,  95 => 10,  89 => 1,  83 => 37,  73 => 29,  71 => 28,  65 => 24,  64 => 23,  63 => 22,  62 => 21,  61 => 20,  57 => 19,  55 => 18,  53 => 8,  51 => 6,  46 => 4,  44 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}
{% set title = \"GraphQL Schemas\"|t('app') %}

{% requireEdition CraftPro %}

{% do view.registerAssetBundle('craft\\\\web\\\\assets\\\\admintable\\\\AdminTableAsset') -%}

{% set selectedSubnavItem = 'schemas' %}

{% block actionButton %}
    <a class=\"btn submit add icon\" href=\"{{ url('graphql/schemas/new') }}\">{{ \"New schema\"|t('app') }}</a>
{% endblock %}

{% block content %}
    <div id=\"schemas-vue-admin-table\"></div>
{% endblock %}

{% set tableData = [] %}
{% for schema in craft.app.gql.schemas %}
\t{% set tableData = tableData|merge([{
        id: schema.id,
        title: schema.isPublic ? 'Public Schema'|t('app') : schema.name|t('site'),
        url: schema.isPublic ? url('graphql/schemas/public') : url(\"graphql/schemas/#{schema.id}\"),
        _showDelete: not schema.isPublic
    }]) %}
{% endfor %}

{% js %}
var columns = [
    { name: '__slot:title', title: Craft.t('app', 'Name') },
];

new Craft.VueAdminTable({
    columns: columns,
    container: '#schemas-vue-admin-table',
    deleteAction: 'graphql/delete-schema',
    tableData: {{ tableData|json_encode|raw }}
});
{% endjs %}
", "graphql/schemas/_index", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/graphql/schemas/_index.twig");
    }
}
