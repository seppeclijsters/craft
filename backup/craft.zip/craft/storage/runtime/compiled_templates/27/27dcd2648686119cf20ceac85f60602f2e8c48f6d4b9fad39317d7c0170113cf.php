<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* seomatic/_includes/facebookPreview.twig */
class __TwigTemplate_475402abc199f10774095af7729b4b383cc05b38dbb25c04a58b6e0b7be28f7d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "seomatic/_includes/facebookPreview.twig");
        // line 1
        $context["ogTitleArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 1, $this->source); })()), "tag", []), "get", [0 => "og:title"], "method"), "renderAttributes", [], "method");
        // line 2
        $context["ogDescriptionArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 2, $this->source); })()), "tag", []), "get", [0 => "og:description"], "method"), "renderAttributes", [], "method");
        // line 3
        $context["ogImageArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 3, $this->source); })()), "tag", []), "get", [0 => "og:image"], "method"), "renderAttributes", [], "method");
        // line 4
        $context["canonicalArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 4, $this->source); })()), "link", []), "get", [0 => "canonical"], "method"), "renderAttributes", [], "method");
        // line 5
        echo "
";
        // line 6
        $context["previewFacebook"] = true;
        // line 10
        $context["showSeoTitleNames"] = (($context["showSeoTitleNames"]) ?? (true));
        // line 11
        $context["previewElementId"] = (($context["previewElementId"]) ?? (0));
        // line 12
        echo "<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"";
        // line 13
        (((array_key_exists("displayPreviewInlineStyles", $context) &&  !(null === (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 13, $this->source); })())))) ? (print (twig_escape_filter($this->env, (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 13, $this->source); })()), "html", null, true))) : (print ("")));
        echo "\">
        ";
        // line 14
        if ((isset($context["showSeoTitleNames"]) || array_key_exists("showSeoTitleNames", $context) ? $context["showSeoTitleNames"] : (function () { throw new RuntimeError('Variable "showSeoTitleNames" does not exist.', 14, $this->source); })())) {
            // line 15
            echo "            <h4 class=\"metadata-title-separator\"><span>Facebook</span></h4>
        ";
        }
        // line 17
        echo "        ";
        if ((isset($context["previewFacebook"]) || array_key_exists("previewFacebook", $context) ? $context["previewFacebook"] : (function () { throw new RuntimeError('Variable "previewFacebook" does not exist.', 17, $this->source); })())) {
            // line 18
            echo "            <div class=\"card-seo-facebook\">
                <a class=\"seo-card-wrapper-link\" href=\"";
            // line 19
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 19, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"))), "html", null, true);
            echo "\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-facebook__image js-preview-image ";
            // line 20
            echo twig_escape_filter($this->env, (isset($context["previewElementId"]) || array_key_exists("previewElementId", $context) ? $context["previewElementId"] : (function () { throw new RuntimeError('Variable "previewElementId" does not exist.', 20, $this->source); })()), "html", null, true);
            echo "-Facebook-post-image\"></div>
                    <div class=\"card-seo-facebook__text\">
                        <span class=\"card-seo-facebook__link js-preview-domain\">
                            ";
            // line 23
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 23, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"), ["http://" => ""]), ["https://" => ""]), ["/" => ""]), "html", null, true);
            echo "
                        </span>
                        <div class=\"card-seo-facebook__content\">
                            <div style=\"margin-top:5px\">
                                <div class=\"card-seo-facebook__title js-preview-title\">
                                    ";
            // line 28
            (((craft\helpers\Template::attribute($this->env, $this->source, ($context["ogTitleArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["ogTitleArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["ogTitleArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
            echo "
                                </div>
                            </div>
                            <span class=\"card-seo-facebook__description js-preview-description\">";
            // line 31
            (((craft\helpers\Template::attribute($this->env, $this->source, ($context["ogDescriptionArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["ogDescriptionArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["ogDescriptionArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
            echo "</span>
                        </div>
                    </div>
                </a>
            </div>

            <script type=\"text/javascript\">
                var x = document.getElementsByClassName(\"";
            // line 38
            echo twig_escape_filter($this->env, (isset($context["previewElementId"]) || array_key_exists("previewElementId", $context) ? $context["previewElementId"] : (function () { throw new RuntimeError('Variable "previewElementId" does not exist.', 38, $this->source); })()), "html", null, true);
            echo "-Facebook-post-image\");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.backgroundImage = \"url('\" + \"";
            // line 41
            echo twig_escape_filter($this->env, ((isset($context["baseAssetsUrl"]) || array_key_exists("baseAssetsUrl", $context) ? $context["baseAssetsUrl"] : (function () { throw new RuntimeError('Variable "baseAssetsUrl" does not exist.', 41, $this->source); })()) . "/img/no_image_set.png"), "html", null, true);
            echo "\" + \"')\";
                    ";
            // line 42
            if ((craft\helpers\Template::attribute($this->env, $this->source, ($context["ogImageArray"] ?? null), "content", [], "any", true, true) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["ogImageArray"]) || array_key_exists("ogImageArray", $context) ? $context["ogImageArray"] : (function () { throw new RuntimeError('Variable "ogImageArray" does not exist.', 42, $this->source); })()), "content", [])))) {
                // line 43
                echo "                    ";
                $context["cacheBustString"] = "";
                // line 44
                echo "                    x[i].style.backgroundImage = \"url('\" + \"";
                echo (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["ogImageArray"]) || array_key_exists("ogImageArray", $context) ? $context["ogImageArray"] : (function () { throw new RuntimeError('Variable "ogImageArray" does not exist.', 44, $this->source); })()), "content", []) . (isset($context["cacheBustString"]) || array_key_exists("cacheBustString", $context) ? $context["cacheBustString"] : (function () { throw new RuntimeError('Variable "cacheBustString" does not exist.', 44, $this->source); })()));
                echo "\" + \"')\";
                    ";
            }
            // line 46
            echo "                }
            </script>
        ";
        } else {
            // line 49
            echo "            ";
            if (( !array_key_exists("previewContext", $context) || ((isset($context["previewContext"]) || array_key_exists("previewContext", $context) ? $context["previewContext"] : (function () { throw new RuntimeError('Variable "previewContext" does not exist.', 49, $this->source); })()) != "sidebar"))) {
                // line 50
                echo "                <div class=\"field\">
                    <p class=\"warning\">No Facebook Profile ID has been set. <a href=\"";
                // line 51
                echo twig_escape_filter($this->env, craft\helpers\UrlHelper::cpUrl("seomatic/site/social"), "html", null, true);
                echo "\">Set it here.</a></p>
                </div>
            ";
            }
            // line 54
            echo "        ";
        }
        // line 55
        echo "    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "seomatic/_includes/facebookPreview.twig");
    }

    public function getTemplateName()
    {
        return "seomatic/_includes/facebookPreview.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 55,  146 => 54,  140 => 51,  137 => 50,  134 => 49,  129 => 46,  123 => 44,  120 => 43,  118 => 42,  114 => 41,  108 => 38,  98 => 31,  92 => 28,  84 => 23,  78 => 20,  74 => 19,  71 => 18,  68 => 17,  64 => 15,  62 => 14,  58 => 13,  55 => 12,  53 => 11,  51 => 10,  49 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set ogTitleArray = seomatic.tag.get('og:title').renderAttributes() %}
{% set ogDescriptionArray = seomatic.tag.get('og:description').renderAttributes() %}
{% set ogImageArray = seomatic.tag.get('og:image').renderAttributes() %}
{% set canonicalArray = seomatic.link.get('canonical').renderAttributes() %}

{% set previewFacebook = true %}
{# Always display the Facebook OpenGraph preview now. Used to be:
set previewFacebook = seomatic.site.facebookAppId |length or seomatic.site.facebookProfileId |length
#}
{% set showSeoTitleNames = showSeoTitleNames ?? true %}
{% set previewElementId = previewElementId ?? 0 %}
<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"{{ displayPreviewInlineStyles ?? '' }}\">
        {% if showSeoTitleNames %}
            <h4 class=\"metadata-title-separator\"><span>Facebook</span></h4>
        {% endif %}
        {% if previewFacebook %}
            <div class=\"card-seo-facebook\">
                <a class=\"seo-card-wrapper-link\" href=\"{{ canonicalArray.href ?? seomatic.helper.siteUrl(\"/\") }}\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-facebook__image js-preview-image {{ previewElementId }}-Facebook-post-image\"></div>
                    <div class=\"card-seo-facebook__text\">
                        <span class=\"card-seo-facebook__link js-preview-domain\">
                            {{ seomatic.helper.siteUrl(\"/\") | replace({'http://': ''}) | replace({'https://': ''})  | replace({'/': ''}) }}
                        </span>
                        <div class=\"card-seo-facebook__content\">
                            <div style=\"margin-top:5px\">
                                <div class=\"card-seo-facebook__title js-preview-title\">
                                    {{ (ogTitleArray.content ?? \"\") }}
                                </div>
                            </div>
                            <span class=\"card-seo-facebook__description js-preview-description\">{{ (ogDescriptionArray.content ?? \"\") }}</span>
                        </div>
                    </div>
                </a>
            </div>

            <script type=\"text/javascript\">
                var x = document.getElementsByClassName(\"{{ previewElementId }}-Facebook-post-image\");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.backgroundImage = \"url('\" + \"{{ baseAssetsUrl ~ '/img/no_image_set.png' }}\" + \"')\";
                    {% if ogImageArray.content is defined and ogImageArray.content |length %}
                    {% set cacheBustString = \"\" %}
                    x[i].style.backgroundImage = \"url('\" + \"{{ (ogImageArray.content ~ cacheBustString) | raw }}\" + \"')\";
                    {% endif %}
                }
            </script>
        {% else %}
            {% if previewContext is not defined or previewContext != \"sidebar\" %}
                <div class=\"field\">
                    <p class=\"warning\">No Facebook Profile ID has been set. <a href=\"{{ cpUrl(\"seomatic/site/social\") }}\">Set it here.</a></p>
                </div>
            {% endif %}
        {% endif %}
    </div>
</div>
", "seomatic/_includes/facebookPreview.twig", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/nystudio107/craft-seomatic/src/templates/_includes/facebookPreview.twig");
    }
}
