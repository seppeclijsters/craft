<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _elements/sources */
class __TwigTemplate_0d5c6b75b71f3d93c283e9c9305529b384dfd0a8260e722cfac397e964c35f1f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_elements/sources");
        // line 1
        ob_start();
        // line 2
        $context["keyPrefix"] = (($context["keyPrefix"]) ?? (""));
        // line 3
        echo "
";
        // line 26
        echo "
";
        // line 53
        echo "
";
        // line 54
        $macros["__internal_parse_2"] = $this->macros["__internal_parse_2"] = $this;
        // line 55
        echo "
<ul>
    ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new RuntimeError('Variable "sources" does not exist.', 57, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
            // line 58
            echo "        ";
            if (((((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "type", [])) : (null)) == "heading")) {
                // line 59
                echo "            <li class=\"heading\"><span>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "heading", []), "site"), "html", null, true);
                echo "</span></li>
        ";
            } else {
                // line 61
                echo "            ";
                $context["key"] = (((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "keyPath", [])) : (((isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 61, $this->source); })()) . craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "key", []))));
                // line 62
                echo "            ";
                ob_start();
                // line 67
                echo "                ";
                echo twig_call_macro($macros["__internal_parse_2"], "macro_sourceLink", [(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 67, $this->source); })()), $context["source"],  !(isset($context["keyPrefix"]) || array_key_exists("keyPrefix", $context) ? $context["keyPrefix"] : (function () { throw new RuntimeError('Variable "keyPrefix" does not exist.', 67, $this->source); })()), (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 67, $this->source); })())], 67, $context, $this->getSourceContext());
                echo "
                ";
                // line 68
                if ((craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [], "any", true, true) &&  !twig_test_empty(craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "nested", [])))) {
                    // line 69
                    echo "                    <button class=\"toggle\" aria-expanded=\"false\" aria-label=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Show nested sources", "app"), "html", null, true);
                    echo "\"></button>
                    ";
                    // line 70
                    $this->loadTemplate("_elements/sources", "_elements/sources", 70)->display(twig_array_merge($context, ["keyPrefix" => (                    // line 71
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 71, $this->source); })()) . "/"), "sources" => craft\helpers\Template::attribute($this->env, $this->source,                     // line 72
$context["source"], "nested", [])]));
                    // line 74
                    echo "                ";
                }
                // line 75
                echo "            ";
                echo craft\helpers\Html::tag("li", ob_get_clean(), ["class" => $this->extensions['craft\web\twig\Extension']->filterFilter($this->env, [0 => (((((craft\helpers\Template::attribute($this->env, $this->source,                 // line 64
$context["source"], "disabled", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["source"], "disabled", [])) : (false))) ? ("hidden") : (null))])]);
                // line 76
                echo "        ";
            }
            // line 77
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 78
        echo "</ul>
";
        $___internal_parse_0_ = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        echo twig_spaceless($___internal_parse_0_);
        craft\helpers\Template::endProfile("template", "_elements/sources");
    }

    // line 4
    public function macro_sourceLink($__key__ = null, $__source__ = null, $__isTopLevel__ = null, $__elementType__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "source" => $__source__,
            "isTopLevel" => $__isTopLevel__,
            "elementType" => $__elementType__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceLink");
            // line 5
            echo "    ";
            $macros["__internal_parse_1"] = $this;
            // line 6
            echo "    ";
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("a", ["data" => $this->extensions['craft\web\twig\Extension']->mergeFilter(["key" =>             // line 8
(isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 8, $this->source); })()), "has-thumbs" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 9
($context["source"] ?? null), "hasThumbs", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "hasThumbs", [])) : (false))) ? (true) : (false)), "has-structure" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 10
($context["source"] ?? null), "structureId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "structureId", [])) : (false))) ? (true) : (false)), "default-sort" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 11
($context["source"] ?? null), "defaultSort", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "defaultSort", [])) : (false))) ? (((twig_test_iterable(craft\helpers\Template::attribute($this->env, $this->source,             // line 12
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", []))) ? (twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", []), ":")) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 12, $this->source); })()), "defaultSort", [])))) : (false)), "sort-options" => ((            // line 14
(isset($context["isTopLevel"]) || array_key_exists("isTopLevel", $context) ? $context["isTopLevel"] : (function () { throw new RuntimeError('Variable "isTopLevel" does not exist.', 14, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter(twig_array_map($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 15
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 15, $this->source); })()), "app", []), "elementSources", []), "getSourceSortOptions", [0 => (isset($context["elementType"]) || array_key_exists("elementType", $context) ? $context["elementType"] : (function () { throw new RuntimeError('Variable "elementType" does not exist.', 15, $this->source); })()), 1 => (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new RuntimeError('Variable "key" does not exist.', 15, $this->source); })())], "method"),             // line 16
function ($__o__) use ($context, $macros) { $context["o"] = $__o__; return [0 => craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 16, $this->source); })()), "label", []), 1 => (((craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["o"] ?? null), "attribute", [])) : (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["o"]) || array_key_exists("o", $context) ? $context["o"] : (function () { throw new RuntimeError('Variable "o" does not exist.', 16, $this->source); })()), "orderBy", [])))]; }))) : (false)), "sites" => (((((craft\helpers\Template::attribute($this->env, $this->source,             // line 19
($context["source"] ?? null), "sites", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "sites", [])) : (false))) ? (twig_join_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 19, $this->source); })()), "sites", []), ",")) : (false)), "override-status" => (((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,             // line 20
($context["source"] ?? null), "criteria", [], "any", false, true), "status", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "criteria", [], "any", false, true), "status", [])) : (false))) ? (true) : (false)), "disabled" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 21
($context["source"] ?? null), "disabled", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "disabled", [])) : (false))], (((craft\helpers\Template::attribute($this->env, $this->source,             // line 22
($context["source"] ?? null), "data", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "data", [])) : ([]))), "html" => twig_call_macro($macros["__internal_parse_1"], "macro_sourceInnerHtml", [            // line 23
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 23, $this->source); })())], 23, $context, $this->getSourceContext())]);
            // line 24
            echo "
";
            craft\helpers\Template::endProfile("macro", "sourceLink");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 27
    public function macro_sourceInnerHtml($__source__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "source" => $__source__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "sourceInnerHtml");
            // line 28
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "status", [], "any", true, true)) {
                // line 29
                echo "        <span class=\"status ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 29, $this->source); })()), "status", []), "html", null, true);
                echo "\"></span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 30
($context["source"] ?? null), "icon", [], "any", true, true)) {
                // line 31
                echo "        <span class=\"icon\">
            ";
                // line 32
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 32, $this->source); })()), "icon", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 32, $this->source); })()), "icon", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 32, $this->source); })()), "icon", [])) . "'></span>")));
                echo "
        </span>
    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 34
($context["source"] ?? null), "iconMask", [], "any", true, true)) {
                // line 35
                echo "        <span class=\"icon icon-mask\">
            ";
                // line 36
                echo (($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 36, $this->source); })()), "iconMask", []), true, true)) ? ($this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 36, $this->source); })()), "iconMask", []), true, true)) : ((("<span data-icon='" . craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 36, $this->source); })()), "iconMask", [])) . "'></span>")));
                echo "
        </span>
    ";
            }
            // line 39
            echo "    <span class=\"label\">";
            echo twig_escape_filter($this->env, (( !(twig_trim_filter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 39, $this->source); })()), "label", [])) === "")) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 39, $this->source); })()), "label", [])) : ($this->extensions['craft\web\twig\Extension']->translateFilter("(blank)", "app"))), "html", null, true);
            echo "</span>
    ";
            // line 40
            if (craft\helpers\Template::attribute($this->env, $this->source, ($context["source"] ?? null), "badgeCount", [], "any", true, true)) {
                // line 41
                echo "        <span class=\"badge\" aria-hidden=\"true\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 41, $this->source); })()), "badgeCount", []), 0), "html", null, true);
                echo "</span>
        ";
                // line 42
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 48
(isset($context["source"]) || array_key_exists("source", $context) ? $context["source"] : (function () { throw new RuntimeError('Variable "source" does not exist.', 48, $this->source); })()), "badgeCount", [])])]);
                // line 50
                echo "
    ";
            }
            craft\helpers\Template::endProfile("macro", "sourceInnerHtml");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_elements/sources";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  243 => 50,  241 => 48,  240 => 42,  235 => 41,  233 => 40,  228 => 39,  222 => 36,  219 => 35,  217 => 34,  212 => 32,  209 => 31,  207 => 30,  202 => 29,  199 => 28,  185 => 27,  174 => 24,  172 => 23,  171 => 22,  170 => 21,  169 => 20,  168 => 19,  167 => 16,  166 => 15,  165 => 14,  164 => 12,  163 => 11,  162 => 10,  161 => 9,  160 => 8,  158 => 6,  155 => 5,  138 => 4,  133 => 1,  129 => 78,  115 => 77,  112 => 76,  110 => 64,  108 => 75,  105 => 74,  103 => 72,  102 => 71,  101 => 70,  96 => 69,  94 => 68,  89 => 67,  86 => 62,  83 => 61,  77 => 59,  74 => 58,  57 => 57,  53 => 55,  51 => 54,  48 => 53,  45 => 26,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% apply spaceless %}
{% set keyPrefix = keyPrefix ?? '' %}

{% macro sourceLink(key, source, isTopLevel, elementType) %}
    {% from _self import sourceInnerHtml %}
    {{ tag('a', {
        data: {
            key: key,
            'has-thumbs': (source.hasThumbs ?? false) ? true : false,
            'has-structure': (source.structureId ?? false) ? true : false,
            'default-sort': (source.defaultSort ?? false)
                ? (source.defaultSort is iterable ? source.defaultSort|join(':') : source.defaultSort)
                : false,
            'sort-options': isTopLevel
                ? craft.app.elementSources.getSourceSortOptions(elementType, key)
                    |map(o => [o.label, o.attribute ?? o.orderBy])
                    |json_encode
                : false,
            sites: (source.sites ?? false) ? source.sites|join(',') : false,
            'override-status': (source.criteria.status ?? false) ? true : false,
            disabled: source.disabled ?? false,
        }|merge(source.data ?? {}),
        html: sourceInnerHtml(source)
    }) }}
{% endmacro %}

{% macro sourceInnerHtml(source) %}
    {% if source.status is defined %}
        <span class=\"status {{ source.status }}\"></span>
    {% elseif source.icon is defined %}
        <span class=\"icon\">
            {{ (svg(source.icon, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.icon}'></span>\")|raw }}
        </span>
    {% elseif source.iconMask is defined %}
        <span class=\"icon icon-mask\">
            {{ (svg(source.iconMask, sanitize=true, namespace=true) ?: \"<span data-icon='#{source.iconMask}'></span>\")|raw }}
        </span>
    {% endif %}
    <span class=\"label\">{{ source.label|trim is not same as('') ? source.label : '(blank)'|t('app') }}</span>
    {% if source.badgeCount is defined %}
        <span class=\"badge\" aria-hidden=\"true\">{{ source.badgeCount|number(decimals=0) }}</span>
        {{ tag('span', {
            class: 'visually-hidden',
            data: {
                notification: true,
            },
            text: '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                num: source.badgeCount,
            }),
        }) }}
    {% endif %}
{% endmacro %}

{% from _self import sourceLink %}

<ul>
    {% for source in sources %}
        {% if (source.type ?? null) == 'heading' %}
            <li class=\"heading\"><span>{{ source.heading|t('site') }}</span></li>
        {% else %}
            {% set key = source.keyPath ?? (keyPrefix ~ source.key) %}
            {% tag 'li' with {
                class: [
                    (source.disabled ?? false) ? 'hidden' : null,
                ]|filter,
            } %}
                {{ sourceLink(key, source, not keyPrefix, elementType) }}
                {% if source.nested is defined and source.nested is not empty %}
                    <button class=\"toggle\" aria-expanded=\"false\" aria-label=\"{{ 'Show nested sources'|t('app') }}\"></button>
                    {% include \"_elements/sources\" with {
                        keyPrefix: key ~ '/',
                        sources: source.nested
                    } %}
                {% endif %}
            {% endtag %}
        {% endif %}
    {% endfor %}
</ul>
{% endapply %}
", "_elements/sources", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_elements/sources.twig");
    }
}
