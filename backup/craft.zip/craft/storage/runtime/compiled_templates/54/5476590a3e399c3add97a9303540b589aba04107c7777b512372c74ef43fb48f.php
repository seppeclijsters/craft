<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__41026fe79f10fdfa55a8e4aea5034175979fb66682a57b322601f2ce212ae46e */
class __TwigTemplate_c98e7f2144914ccd2eb810068d3766e160fee4e69bc70a422e6e1b15b15b4b3b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__41026fe79f10fdfa55a8e4aea5034175979fb66682a57b322601f2ce212ae46e");
        // line 1
        echo (((craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "url", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "url", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["_variables"] ?? null), "url", [])) : (craft\helpers\Template::attribute($this->env, $this->source, ($context["object"] ?? null), "url", [])));
        craft\helpers\Template::endProfile("template", "__string_template__41026fe79f10fdfa55a8e4aea5034175979fb66682a57b322601f2ce212ae46e");
    }

    public function getTemplateName()
    {
        return "__string_template__41026fe79f10fdfa55a8e4aea5034175979fb66682a57b322601f2ce212ae46e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ (_variables.url ?? object.url)|raw }}", "__string_template__41026fe79f10fdfa55a8e4aea5034175979fb66682a57b322601f2ce212ae46e", "");
    }
}
