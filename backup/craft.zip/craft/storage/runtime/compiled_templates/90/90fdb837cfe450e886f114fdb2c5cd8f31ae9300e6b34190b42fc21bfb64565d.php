<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__393d966d1a745205d6346443a9d894e099437e86feed826baf7c1451a628d9bf */
class __TwigTemplate_705265f9f8ad1d6f61b842584b6620d763c2cb6d6e114103b06964e56d539924 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__393d966d1a745205d6346443a9d894e099437e86feed826baf7c1451a628d9bf");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "seoImageWidth", []);
        craft\helpers\Template::endProfile("template", "__string_template__393d966d1a745205d6346443a9d894e099437e86feed826baf7c1451a628d9bf");
    }

    public function getTemplateName()
    {
        return "__string_template__393d966d1a745205d6346443a9d894e099437e86feed826baf7c1451a628d9bf";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.seoImageWidth }}", "__string_template__393d966d1a745205d6346443a9d894e099437e86feed826baf7c1451a628d9bf", "");
    }
}
