<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _components/utilities/Updates */
class __TwigTemplate_869ee339b4728def58837c18a4865b417f7001ce0cd36ece5d1cca5e2d97d43a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_components/utilities/Updates");
        // line 1
        echo "<div id=\"graphic\" class=\"spinner big\"></div>
<div id=\"status\">";
        // line 2
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Checking for updates…", "app"), "html", null, true);
        echo "</div>
";
        craft\helpers\Template::endProfile("template", "_components/utilities/Updates");
    }

    public function getTemplateName()
    {
        return "_components/utilities/Updates";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div id=\"graphic\" class=\"spinner big\"></div>
<div id=\"status\">{{ \"Checking for updates…\"|t('app') }}</div>
", "_components/utilities/Updates", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_components/utilities/Updates.twig");
    }
}
