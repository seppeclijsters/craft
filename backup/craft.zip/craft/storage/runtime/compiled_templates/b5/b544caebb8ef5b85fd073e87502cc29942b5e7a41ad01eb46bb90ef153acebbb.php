<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* typedlinkfield/_input */
class __TwigTemplate_97f3c174c952e16adcbde3ad7dc5fe6fa0412543c7c22a006ff262f31a5aae0c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "typedlinkfield/_input");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_input", 1)->unwrap();
        // line 2
        $macros["self"] = $this->macros["self"] = $this;
        // line 3
        echo "
";
        // line 4
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 4, $this->source); })()), "registerAssetBundle", [0 => "lenz\\linkfield\\assets\\field\\LinkFieldAsset"], "method");
        // line 5
        echo "
";
        // line 6
        $context["selectedTypeName"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 6, $this->source); })()), "resolveSelectedLinkTypeName", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 6, $this->source); })())], "method");
        // line 7
        $context["linkTypes"] = craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 7, $this->source); })()), "enabledLinkTypes", []);
        // line 8
        $context["isEmpty"] = (((isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 8, $this->source); })()) == "") || ((isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 8, $this->source); })()) == "empty"));
        // line 9
        echo "
";
        // line 20
        echo "
";
        // line 21
        $_namespace = (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 21, $this->source); })());
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 22
                echo "  <div class=\"linkfield";
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 22, $this->source); })()), "hasSettings", [])) {
                    echo " withSettings";
                }
                echo "\" id=\"";
                echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 22, $this->source); })()), "html", null, true);
                echo "\">
    ";
                // line 23
                if (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new RuntimeError('Variable "linkTypes" does not exist.', 23, $this->source); })())) == 0)) {
                    // line 24
                    echo "      <p>";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No link types available.", "typedlinkfield"), "html", null, true);
                    echo "</p>
    ";
                } else {
                    // line 26
                    echo "      <div class=\"linkfield--field\">
        ";
                    // line 27
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 27, $this->source); })()), "hasSingleLinkType", [])) {
                        // line 28
                        echo "          <input type=\"hidden\" id=\"type\" name=\"type\" value=\"";
                        echo twig_escape_filter($this->env, (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 28, $this->source); })()), "html", null, true);
                        echo "\" />
        ";
                    } else {
                        // line 30
                        echo "          <div class=\"linkfield--type\">
            ";
                        // line 31
                        echo twig_call_macro($macros["forms"], "macro_select", [["id" => "type", "name" => "type", "disabled" =>                         // line 34
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 34, $this->source); })()), "options" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                         // line 35
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 35, $this->source); })()), "enabledLinkTypes", []), "displayNames", []), "value" =>                         // line 36
(isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 36, $this->source); })())]], 31, $context, $this->getSourceContext());
                        // line 37
                        echo "
          </div>
        ";
                    }
                    // line 40
                    echo "
        <div class=\"linkfield--typeOptions";
                    // line 41
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 41, $this->source); })()), "hasSingleLinkType", [])) {
                        echo " single";
                    }
                    echo "\">
          ";
                    // line 42
                    echo twig_call_macro($macros["self"], "macro_typeSettings", [(isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new RuntimeError('Variable "linkTypes" does not exist.', 42, $this->source); })()), (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 42, $this->source); })()), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 42, $this->source); })()), (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 42, $this->source); })())], 42, $context, $this->getSourceContext());
                    echo "
        </div>

        ";
                    // line 45
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "allowTarget", [])) {
                        // line 46
                        echo "          <div class=\"linkfield--target";
                        echo (((isset($context["isEmpty"]) || array_key_exists("isEmpty", $context) ? $context["isEmpty"] : (function () { throw new RuntimeError('Variable "isEmpty" does not exist.', 46, $this->source); })())) ? (" hidden") : (""));
                        echo "\">
            ";
                        // line 47
                        echo twig_call_macro($macros["forms"], "macro_checkboxField", [["id" => "target", "name" => "target", "value" => "_blank", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Open in new window?", "typedlinkfield"), "checked" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 52
($context["value"] ?? null), "target", [], "any", true, true) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 52, $this->source); })()), "target", []) == "_blank"))) ? (true) : (null)), "disabled" =>                         // line 53
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 53, $this->source); })())]], 47, $context, $this->getSourceContext());
                        // line 54
                        echo "
          </div>
        ";
                    }
                    // line 57
                    echo "      </div>

      ";
                    // line 59
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 59, $this->source); })()), "hasSettings", [])) {
                        // line 60
                        echo "        <div class=\"linkfield--settings";
                        echo (((isset($context["isEmpty"]) || array_key_exists("isEmpty", $context) ? $context["isEmpty"] : (function () { throw new RuntimeError('Variable "isEmpty" does not exist.', 60, $this->source); })())) ? (" hidden") : (""));
                        echo "\">
          ";
                        // line 61
                        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), "allowCustomText", [])) {
                            // line 62
                            echo "            ";
                            echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                             // line 63
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 63, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 64
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 64, $this->source); })()), "getErrors", [0 => "customText"], "method"), "id" => "customText", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom link text", "typedlinkfield"), "name" => "customText", "maxlength" => (((craft\helpers\Template::attribute($this->env, $this->source,                             // line 68
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "customTextMaxLength", []) > 0)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "customTextMaxLength", [])) : (false)), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                             // line 69
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), "defaultText", []) == "")) ? ("") : ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), "defaultText", []), "site"))), "required" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 70
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 70, $this->source); })()), "customTextRequired", []), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                             // line 71
($context["value"] ?? null), "customText", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 71, $this->source); })()), "customText", []))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 71, $this->source); })()), "customText", [])) : (""))]], 62, $context, $this->getSourceContext());
                            // line 72
                            echo "
          ";
                        }
                        // line 74
                        echo "
          ";
                        // line 75
                        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 75, $this->source); })()), "enableAriaLabel", [])) {
                            // line 76
                            echo "            ";
                            echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                             // line 77
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 77, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 78
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 78, $this->source); })()), "getErrors", [0 => "ariaLabel"], "method"), "id" => "ariaLabel", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Aria label", "typedlinkfield"), "name" => "ariaLabel", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,                             // line 82
($context["value"] ?? null), "ariaLabel", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 82, $this->source); })()), "ariaLabel", [])) : (""))]], 76, $context, $this->getSourceContext());
                            // line 83
                            echo "
          ";
                        }
                        // line 85
                        echo "
          ";
                        // line 86
                        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 86, $this->source); })()), "enableTitle", [])) {
                            // line 87
                            echo "            ";
                            echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                             // line 88
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 88, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                             // line 89
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 89, $this->source); })()), "getErrors", [0 => "title"], "method"), "id" => "title", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "typedlinkfield"), "name" => "title", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,                             // line 93
($context["value"] ?? null), "title", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 93, $this->source); })()), "title", [])) : (""))]], 87, $context, $this->getSourceContext());
                            // line 94
                            echo "
          ";
                        }
                        // line 96
                        echo "        </div>
      ";
                    }
                    // line 98
                    echo "    ";
                }
                // line 99
                echo "  </div>

  ";
                // line 101
                ob_start();
                // line 102
                echo "    new LinkField(\"";
                echo twig_escape_filter($this->env, $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 102, $this->source); })())), "html", null, true);
                echo "\");
  ";
                craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 22
            echo "  <div class=\"linkfield";
            if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 22, $this->source); })()), "hasSettings", [])) {
                echo " withSettings";
            }
            echo "\" id=\"";
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 22, $this->source); })()), "html", null, true);
            echo "\">
    ";
            // line 23
            if (($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, (isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new RuntimeError('Variable "linkTypes" does not exist.', 23, $this->source); })())) == 0)) {
                // line 24
                echo "      <p>";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No link types available.", "typedlinkfield"), "html", null, true);
                echo "</p>
    ";
            } else {
                // line 26
                echo "      <div class=\"linkfield--field\">
        ";
                // line 27
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 27, $this->source); })()), "hasSingleLinkType", [])) {
                    // line 28
                    echo "          <input type=\"hidden\" id=\"type\" name=\"type\" value=\"";
                    echo twig_escape_filter($this->env, (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 28, $this->source); })()), "html", null, true);
                    echo "\" />
        ";
                } else {
                    // line 30
                    echo "          <div class=\"linkfield--type\">
            ";
                    // line 31
                    echo twig_call_macro($macros["forms"], "macro_select", [["id" => "type", "name" => "type", "disabled" =>                     // line 34
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 34, $this->source); })()), "options" => craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source,                     // line 35
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 35, $this->source); })()), "enabledLinkTypes", []), "displayNames", []), "value" =>                     // line 36
(isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 36, $this->source); })())]], 31, $context, $this->getSourceContext());
                    // line 37
                    echo "
          </div>
        ";
                }
                // line 40
                echo "
        <div class=\"linkfield--typeOptions";
                // line 41
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 41, $this->source); })()), "hasSingleLinkType", [])) {
                    echo " single";
                }
                echo "\">
          ";
                // line 42
                echo twig_call_macro($macros["self"], "macro_typeSettings", [(isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new RuntimeError('Variable "linkTypes" does not exist.', 42, $this->source); })()), (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 42, $this->source); })()), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 42, $this->source); })()), (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 42, $this->source); })())], 42, $context, $this->getSourceContext());
                echo "
        </div>

        ";
                // line 45
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 45, $this->source); })()), "allowTarget", [])) {
                    // line 46
                    echo "          <div class=\"linkfield--target";
                    echo (((isset($context["isEmpty"]) || array_key_exists("isEmpty", $context) ? $context["isEmpty"] : (function () { throw new RuntimeError('Variable "isEmpty" does not exist.', 46, $this->source); })())) ? (" hidden") : (""));
                    echo "\">
            ";
                    // line 47
                    echo twig_call_macro($macros["forms"], "macro_checkboxField", [["id" => "target", "name" => "target", "value" => "_blank", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Open in new window?", "typedlinkfield"), "checked" => (((craft\helpers\Template::attribute($this->env, $this->source,                     // line 52
($context["value"] ?? null), "target", [], "any", true, true) && (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 52, $this->source); })()), "target", []) == "_blank"))) ? (true) : (null)), "disabled" =>                     // line 53
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 53, $this->source); })())]], 47, $context, $this->getSourceContext());
                    // line 54
                    echo "
          </div>
        ";
                }
                // line 57
                echo "      </div>

      ";
                // line 59
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 59, $this->source); })()), "hasSettings", [])) {
                    // line 60
                    echo "        <div class=\"linkfield--settings";
                    echo (((isset($context["isEmpty"]) || array_key_exists("isEmpty", $context) ? $context["isEmpty"] : (function () { throw new RuntimeError('Variable "isEmpty" does not exist.', 60, $this->source); })())) ? (" hidden") : (""));
                    echo "\">
          ";
                    // line 61
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 61, $this->source); })()), "allowCustomText", [])) {
                        // line 62
                        echo "            ";
                        echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                         // line 63
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 63, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 64
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 64, $this->source); })()), "getErrors", [0 => "customText"], "method"), "id" => "customText", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom link text", "typedlinkfield"), "name" => "customText", "maxlength" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 68
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "customTextMaxLength", []) > 0)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 68, $this->source); })()), "customTextMaxLength", [])) : (false)), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 69
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), "defaultText", []) == "")) ? ("") : ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 69, $this->source); })()), "defaultText", []), "site"))), "required" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 70
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 70, $this->source); })()), "customTextRequired", []), "value" => (((craft\helpers\Template::attribute($this->env, $this->source,                         // line 71
($context["value"] ?? null), "customText", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 71, $this->source); })()), "customText", []))) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 71, $this->source); })()), "customText", [])) : (""))]], 62, $context, $this->getSourceContext());
                        // line 72
                        echo "
          ";
                    }
                    // line 74
                    echo "
          ";
                    // line 75
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 75, $this->source); })()), "enableAriaLabel", [])) {
                        // line 76
                        echo "            ";
                        echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                         // line 77
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 77, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 78
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 78, $this->source); })()), "getErrors", [0 => "ariaLabel"], "method"), "id" => "ariaLabel", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Aria label", "typedlinkfield"), "name" => "ariaLabel", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,                         // line 82
($context["value"] ?? null), "ariaLabel", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 82, $this->source); })()), "ariaLabel", [])) : (""))]], 76, $context, $this->getSourceContext());
                        // line 83
                        echo "
          ";
                    }
                    // line 85
                    echo "
          ";
                    // line 86
                    if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new RuntimeError('Variable "field" does not exist.', 86, $this->source); })()), "enableTitle", [])) {
                        // line 87
                        echo "            ";
                        echo twig_call_macro($macros["forms"], "macro_textField", [["disabled" =>                         // line 88
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 88, $this->source); })()), "errors" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 89
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 89, $this->source); })()), "getErrors", [0 => "title"], "method"), "id" => "title", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "typedlinkfield"), "name" => "title", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,                         // line 93
($context["value"] ?? null), "title", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 93, $this->source); })()), "title", [])) : (""))]], 87, $context, $this->getSourceContext());
                        // line 94
                        echo "
          ";
                    }
                    // line 96
                    echo "        </div>
      ";
                }
                // line 98
                echo "    ";
            }
            // line 99
            echo "  </div>

  ";
            // line 101
            ob_start();
            // line 102
            echo "    new LinkField(\"";
            echo twig_escape_filter($this->env, $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 102, $this->source); })())), "html", null, true);
            echo "\");
  ";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        unset($_originalNamespace, $_namespace);
        craft\helpers\Template::endProfile("template", "typedlinkfield/_input");
    }

    // line 11
    public function macro_typeSettings($__linkTypes__ = null, $__selectedTypeName__ = null, $__value__ = null, $__disabled__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "linkTypes" => $__linkTypes__,
            "selectedTypeName" => $__selectedTypeName__,
            "value" => $__value__,
            "disabled" => $__disabled__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "typeSettings");
            // line 12
            echo "  ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new RuntimeError('Variable "linkTypes" does not exist.', 12, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["linkType"]) {
                // line 13
                echo "    ";
                $_namespace = (("cpForm[" . craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "name", [])) . "]");
                if ($_namespace) {
                    $_originalNamespace = Craft::$app->getView()->getNamespace();
                    Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                    ob_start();
                    try {
                        // line 14
                        echo "      <div class=\"linkfield--typeOption ";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "name", []), "html", null, true);
                        echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "name", []) == (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 14, $this->source); })()))) ? ("") : (" hidden"));
                        echo "\">
        ";
                        // line 15
                        echo craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "inputHtml", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 15, $this->source); })()), 1 => (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 15, $this->source); })())], "method");
                        echo "
      </div>
    ";
                    } catch (Exception $e) {
                        ob_end_clean();

                        throw $e;
                    }
                    echo craft\helpers\Html::namespaceHtml(ob_get_clean(), $_namespace, false);
                    Craft::$app->getView()->setNamespace($_originalNamespace);
                } else {
                    // line 14
                    echo "      <div class=\"linkfield--typeOption ";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "name", []), "html", null, true);
                    echo (((craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "name", []) == (isset($context["selectedTypeName"]) || array_key_exists("selectedTypeName", $context) ? $context["selectedTypeName"] : (function () { throw new RuntimeError('Variable "selectedTypeName" does not exist.', 14, $this->source); })()))) ? ("") : (" hidden"));
                    echo "\">
        ";
                    // line 15
                    echo craft\helpers\Template::attribute($this->env, $this->source, $context["linkType"], "inputHtml", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 15, $this->source); })()), 1 => (isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 15, $this->source); })())], "method");
                    echo "
      </div>
    ";
                }
                unset($_originalNamespace, $_namespace);
                // line 18
                echo "  ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['linkType'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            craft\helpers\Template::endProfile("macro", "typeSettings");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  438 => 18,  431 => 15,  425 => 14,  412 => 15,  406 => 14,  398 => 13,  393 => 12,  376 => 11,  365 => 102,  363 => 101,  359 => 99,  356 => 98,  352 => 96,  348 => 94,  346 => 93,  345 => 89,  344 => 88,  342 => 87,  340 => 86,  337 => 85,  333 => 83,  331 => 82,  330 => 78,  329 => 77,  327 => 76,  325 => 75,  322 => 74,  318 => 72,  316 => 71,  315 => 70,  314 => 69,  313 => 68,  312 => 64,  311 => 63,  309 => 62,  307 => 61,  302 => 60,  300 => 59,  296 => 57,  291 => 54,  289 => 53,  288 => 52,  287 => 47,  282 => 46,  280 => 45,  274 => 42,  268 => 41,  265 => 40,  260 => 37,  258 => 36,  257 => 35,  256 => 34,  255 => 31,  252 => 30,  246 => 28,  244 => 27,  241 => 26,  235 => 24,  233 => 23,  224 => 22,  210 => 102,  208 => 101,  204 => 99,  201 => 98,  197 => 96,  193 => 94,  191 => 93,  190 => 89,  189 => 88,  187 => 87,  185 => 86,  182 => 85,  178 => 83,  176 => 82,  175 => 78,  174 => 77,  172 => 76,  170 => 75,  167 => 74,  163 => 72,  161 => 71,  160 => 70,  159 => 69,  158 => 68,  157 => 64,  156 => 63,  154 => 62,  152 => 61,  147 => 60,  145 => 59,  141 => 57,  136 => 54,  134 => 53,  133 => 52,  132 => 47,  127 => 46,  125 => 45,  119 => 42,  113 => 41,  110 => 40,  105 => 37,  103 => 36,  102 => 35,  101 => 34,  100 => 31,  97 => 30,  91 => 28,  89 => 27,  86 => 26,  80 => 24,  78 => 23,  69 => 22,  62 => 21,  59 => 20,  56 => 9,  54 => 8,  52 => 7,  50 => 6,  47 => 5,  45 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}
{% import _self as self %}

{% do view.registerAssetBundle('lenz\\\\linkfield\\\\assets\\\\field\\\\LinkFieldAsset') %}

{% set selectedTypeName = field.resolveSelectedLinkTypeName(value) %}
{% set linkTypes = field.enabledLinkTypes %}
{% set isEmpty = selectedTypeName == '' or selectedTypeName == 'empty' %}

{# Must be a macro as there is an issue with nested namespace nodes #}
{% macro typeSettings(linkTypes, selectedTypeName, value, disabled) %}
  {% for linkType in linkTypes %}
    {% namespace 'cpForm['~linkType.name~']' %}
      <div class=\"linkfield--typeOption {{ linkType.name }}{{ linkType.name == selectedTypeName ? '' : ' hidden' }}\">
        {{ linkType.inputHtml(value, disabled)|raw }}
      </div>
    {% endnamespace %}
  {% endfor %}
{% endmacro %}

{% namespace name %}
  <div class=\"linkfield{% if field.hasSettings %} withSettings{% endif %}\" id=\"{{ name }}\">
    {% if linkTypes|length == 0 %}
      <p>{{ 'No link types available.'|t('typedlinkfield') }}</p>
    {% else %}
      <div class=\"linkfield--field\">
        {% if field.hasSingleLinkType %}
          <input type=\"hidden\" id=\"type\" name=\"type\" value=\"{{ selectedTypeName }}\" />
        {% else %}
          <div class=\"linkfield--type\">
            {{ forms.select({
              id:       'type',
              name:     'type',
              disabled: disabled,
              options:  field.enabledLinkTypes.displayNames,
              value:    selectedTypeName
            }) }}
          </div>
        {% endif %}

        <div class=\"linkfield--typeOptions{% if field.hasSingleLinkType %} single{% endif %}\">
          {{ self.typeSettings(linkTypes, selectedTypeName, value, disabled) }}
        </div>

        {% if field.allowTarget %}
          <div class=\"linkfield--target{{ isEmpty ? ' hidden' }}\">
            {{ forms.checkboxField({
              id:       'target',
              name:     'target',
              value:    '_blank',
              label:    'Open in new window?'|t('typedlinkfield'),
              checked:  value.target is defined and value.target == '_blank' ? true : null,
              disabled: disabled,
            }) }}
          </div>
        {% endif %}
      </div>

      {% if field.hasSettings %}
        <div class=\"linkfield--settings{{ isEmpty ? ' hidden' }}\">
          {% if field.allowCustomText %}
            {{ forms.textField({
              disabled:    disabled,
              errors:      value.getErrors('customText'),
              id:          'customText',
              label:       'Custom link text'|t('typedlinkfield'),
              name:        'customText',
              maxlength:   field.customTextMaxLength > 0 ? field.customTextMaxLength : false,
              placeholder: field.defaultText == '' ? '' : field.defaultText|t('site'),
              required:    field.customTextRequired,
              value:       value.customText is defined and value.customText ? value.customText : '',
            }) }}
          {% endif %}

          {% if field.enableAriaLabel %}
            {{ forms.textField({
              disabled: disabled,
              errors:   value.getErrors('ariaLabel'),
              id:       'ariaLabel',
              label:    'Aria label'|t('typedlinkfield'),
              name:     'ariaLabel',
              value:    value.ariaLabel is defined ? value.ariaLabel : \"\",
            }) }}
          {% endif %}

          {% if field.enableTitle %}
            {{ forms.textField({
              disabled: disabled,
              errors:   value.getErrors('title'),
              id:       'title',
              label:    'Title'|t('typedlinkfield'),
              name:     'title',
              value:    value.title is defined ? value.title : \"\",
            }) }}
          {% endif %}
        </div>
      {% endif %}
    {% endif %}
  </div>

  {% js %}
    new LinkField(\"{{ name|namespaceInputId }}\");
  {% endjs %}
{% endnamespace %}
", "typedlinkfield/_input", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/sebastianlenz/linkfield/src/templates/_input.twig");
    }
}
