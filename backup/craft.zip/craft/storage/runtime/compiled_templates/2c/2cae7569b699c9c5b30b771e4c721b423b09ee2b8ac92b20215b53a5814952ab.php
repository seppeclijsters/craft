<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* seomatic/_includes/googlePreview.twig */
class __TwigTemplate_256130ab39b1a562e1039b9036b1d4d7f4e40786e332147ae74d9bbbaf520c07 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "seomatic/_includes/googlePreview.twig");
        // line 1
        $context["titleArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 1, $this->source); })()), "title", []), "get", [0 => "title"], "method"), "renderAttributes", [], "method");
        // line 2
        $context["descriptionArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 2, $this->source); })()), "tag", []), "get", [0 => "description"], "method"), "renderAttributes", [], "method");
        // line 3
        $context["canonicalArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 3, $this->source); })()), "link", []), "get", [0 => "canonical"], "method"), "renderAttributes", [], "method");
        // line 4
        echo "
";
        // line 5
        $context["showSeoTitleNames"] = (($context["showSeoTitleNames"]) ?? (true));
        // line 6
        echo "<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"";
        // line 7
        (((array_key_exists("displayPreviewInlineStyles", $context) &&  !(null === (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 7, $this->source); })())))) ? (print (twig_escape_filter($this->env, (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 7, $this->source); })()), "html", null, true))) : (print ("")));
        echo "\">
        ";
        // line 8
        if ((isset($context["showSeoTitleNames"]) || array_key_exists("showSeoTitleNames", $context) ? $context["showSeoTitleNames"] : (function () { throw new RuntimeError('Variable "showSeoTitleNames" does not exist.', 8, $this->source); })())) {
            // line 9
            echo "            <h4 class=\"metadata-title-separator\"><span>Google</span></h4>
        ";
        }
        // line 11
        echo "        <div class=\"card-seo-google\">
            <span class=\"card-seo-google__title js-preview-title\"><a class=\"googleDisplay\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 12, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"))), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\">";
        (((craft\helpers\Template::attribute($this->env, $this->source, ($context["titleArray"] ?? null), "title", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["titleArray"] ?? null), "title", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["titleArray"] ?? null), "title", []), "html", null, true))) : (print ("")));
        echo "</a></span>
            <div class=\"card-seo-google__url\">
                <span class=\"card-seo-google__url-title js-preview-domain\">";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter((((craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 14, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"))), ["http://" => ""]), ["https://" => ""]), "html", null, true);
        echo "</span>
                <span class=\"card-seo-google__url-arrow\"></span>
            </div>
            <span class=\"card-seo-google__description js-preview-description\">
              ";
        // line 18
        (((craft\helpers\Template::attribute($this->env, $this->source, ($context["descriptionArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["descriptionArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["descriptionArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
        echo "
            </span>
        </div>
    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "seomatic/_includes/googlePreview.twig");
    }

    public function getTemplateName()
    {
        return "seomatic/_includes/googlePreview.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 18,  72 => 14,  65 => 12,  62 => 11,  58 => 9,  56 => 8,  52 => 7,  49 => 6,  47 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set titleArray = seomatic.title.get('title').renderAttributes() %}
{% set descriptionArray = seomatic.tag.get('description').renderAttributes() %}
{% set canonicalArray = seomatic.link.get('canonical').renderAttributes() %}

{% set showSeoTitleNames = showSeoTitleNames ?? true %}
<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"{{ displayPreviewInlineStyles ?? '' }}\">
        {% if showSeoTitleNames %}
            <h4 class=\"metadata-title-separator\"><span>Google</span></h4>
        {% endif %}
        <div class=\"card-seo-google\">
            <span class=\"card-seo-google__title js-preview-title\"><a class=\"googleDisplay\" href=\"{{ canonicalArray.href ?? seomatic.helper.siteUrl(\"/\") }}\" rel=\"noopener\" target=\"_blank\">{{ (titleArray.title ?? \"\") }}</a></span>
            <div class=\"card-seo-google__url\">
                <span class=\"card-seo-google__url-title js-preview-domain\">{{ (canonicalArray.href ?? seomatic.helper.siteUrl(\"/\")) | replace({'http://': ''}) | replace({'https://': ''}) }}</span>
                <span class=\"card-seo-google__url-arrow\"></span>
            </div>
            <span class=\"card-seo-google__description js-preview-description\">
              {{ (descriptionArray.content ?? \"\") }}
            </span>
        </div>
    </div>
</div>
", "seomatic/_includes/googlePreview.twig", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/nystudio107/craft-seomatic/src/templates/_includes/googlePreview.twig");
    }
}
