<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__66b17b65b79357093be2690e74a59f72862390e5a93a543e1c3103d4c44f2a73 */
class __TwigTemplate_2b7234c7aefaeb2b19498a057db631bf4028ba718ca2d2b9b2aa7b0c8f8c785f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__66b17b65b79357093be2690e74a59f72862390e5a93a543e1c3103d4c44f2a73");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "ogSiteNamePosition", []);
        craft\helpers\Template::endProfile("template", "__string_template__66b17b65b79357093be2690e74a59f72862390e5a93a543e1c3103d4c44f2a73");
    }

    public function getTemplateName()
    {
        return "__string_template__66b17b65b79357093be2690e74a59f72862390e5a93a543e1c3103d4c44f2a73";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.ogSiteNamePosition }}", "__string_template__66b17b65b79357093be2690e74a59f72862390e5a93a543e1c3103d4c44f2a73", "");
    }
}
