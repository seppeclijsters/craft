<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__d72139d68aa6813612e24ea1a4f6201140d89d0cff0ee66c182b3eb8fb8669c0 */
class __TwigTemplate_54b45215ebf8d0beb6fe5ede82cfe12a14389fbd5117b0ae2c6a46c86b3bf2d4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__d72139d68aa6813612e24ea1a4f6201140d89d0cff0ee66c182b3eb8fb8669c0");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "title", []);
        craft\helpers\Template::endProfile("template", "__string_template__d72139d68aa6813612e24ea1a4f6201140d89d0cff0ee66c182b3eb8fb8669c0");
    }

    public function getTemplateName()
    {
        return "__string_template__d72139d68aa6813612e24ea1a4f6201140d89d0cff0ee66c182b3eb8fb8669c0";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ entry.title }}", "__string_template__d72139d68aa6813612e24ea1a4f6201140d89d0cff0ee66c182b3eb8fb8669c0", "");
    }
}
