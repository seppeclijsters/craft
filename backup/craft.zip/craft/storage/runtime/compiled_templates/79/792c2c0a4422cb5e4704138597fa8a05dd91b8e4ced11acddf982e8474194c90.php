<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* seomatic/_includes/twitterPreview.twig */
class __TwigTemplate_a60c122006d08d6ee44729cb74c363c218980dba59cc0248343d47a6858ea19e extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "seomatic/_includes/twitterPreview.twig");
        // line 1
        $context["twitterTitleArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 1, $this->source); })()), "tag", []), "get", [0 => "twitter:title"], "method"), "renderAttributes", [], "method");
        // line 2
        $context["twitterDescriptionArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 2, $this->source); })()), "tag", []), "get", [0 => "twitter:description"], "method"), "renderAttributes", [], "method");
        // line 3
        $context["twitterImageArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 3, $this->source); })()), "tag", []), "get", [0 => "twitter:image"], "method"), "renderAttributes", [], "method");
        // line 4
        $context["canonicalArray"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 4, $this->source); })()), "link", []), "get", [0 => "canonical"], "method"), "renderAttributes", [], "method");
        // line 5
        echo "
";
        // line 6
        $context["showSeoTitleNames"] = (($context["showSeoTitleNames"]) ?? (true));
        // line 7
        $context["previewElementId"] = (($context["previewElementId"]) ?? (0));
        // line 8
        echo "<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"";
        // line 9
        (((array_key_exists("displayPreviewInlineStyles", $context) &&  !(null === (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 9, $this->source); })())))) ? (print (twig_escape_filter($this->env, (isset($context["displayPreviewInlineStyles"]) || array_key_exists("displayPreviewInlineStyles", $context) ? $context["displayPreviewInlineStyles"] : (function () { throw new RuntimeError('Variable "displayPreviewInlineStyles" does not exist.', 9, $this->source); })()), "html", null, true))) : (print ("")));
        echo "\">
        ";
        // line 10
        if ((isset($context["showSeoTitleNames"]) || array_key_exists("showSeoTitleNames", $context) ? $context["showSeoTitleNames"] : (function () { throw new RuntimeError('Variable "showSeoTitleNames" does not exist.', 10, $this->source); })())) {
            // line 11
            echo "            <h4 class=\"metadata-title-separator\"><span>Twitter</span></h4>
        ";
        }
        // line 13
        echo "        ";
        if ($this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 13, $this->source); })()), "site", []), "twitterHandle", []))) {
            // line 14
            echo "            ";
            $context["lg"] = false;
            // line 15
            echo "            ";
            if ((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 15, $this->source); })()), "meta", []), "twitterCard", []) == "summary_large_image")) {
                // line 16
                echo "                ";
                $context["lg"] = true;
                // line 17
                echo "            ";
            }
            // line 18
            echo "            ";
            if ((isset($context["lg"]) || array_key_exists("lg", $context) ? $context["lg"] : (function () { throw new RuntimeError('Variable "lg" does not exist.', 18, $this->source); })())) {
                // line 19
                echo "            <div class=\"card-seo-twitter\">
                <a class=\"seo-card-wrapper-link\" href=\"";
                // line 20
                echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 20, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"))), "html", null, true);
                echo "\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-twitter__image js-preview-image ";
                // line 21
                echo twig_escape_filter($this->env, (isset($context["previewElementId"]) || array_key_exists("previewElementId", $context) ? $context["previewElementId"] : (function () { throw new RuntimeError('Variable "previewElementId" does not exist.', 21, $this->source); })()), "html", null, true);
                echo "-TwitterCard-image-wrapper\"></div>
                    <div class=\"card-seo-twitter__text\">
                        <span class=\"card-seo-twitter__title js-preview-title\">
                            ";
                // line 24
                (((craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
                echo "
                        </span>
                        <span class=\"card-seo-twitter__description js-preview-description\">
                            ";
                // line 27
                (((craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
                echo "
                        </span>
                        <span class=\"card-seo-twitter__link js-preview-domain\">
                            ";
                // line 30
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 30, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"), ["http://" => ""]), ["https://" => ""]), ["/" => ""]), "html", null, true);
                echo "
                        </span>
                    </div>
                </a>
            </div>
            ";
            } else {
                // line 36
                echo "            <div class=\"card-seo-twitter\">
                <a class=\"seo-card-wrapper-link\" href=\"";
                // line 37
                echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, ($context["canonicalArray"] ?? null), "href", [])) : (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 37, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"))), "html", null, true);
                echo "\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-twitter__image js-preview-image card-seo-twitter__image-summary ";
                // line 38
                echo twig_escape_filter($this->env, (isset($context["previewElementId"]) || array_key_exists("previewElementId", $context) ? $context["previewElementId"] : (function () { throw new RuntimeError('Variable "previewElementId" does not exist.', 38, $this->source); })()), "html", null, true);
                echo "-TwitterCard-image-wrapper\"></div>
                    <div class=\"card-seo-twitter__text card-seo-twitter__text-summary\">
                        <span class=\"card-seo-twitter__title js-preview-title\">
                            ";
                // line 41
                (((craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterTitleArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
                echo "
                        </span>
                        <span class=\"card-seo-twitter__description card-seo-twitter__description-summary js-preview-description\">
                            ";
                // line 44
                (((craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", [])))) ? (print (twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterDescriptionArray"] ?? null), "content", []), "html", null, true))) : (print ("")));
                echo "
                        </span>
                        <span class=\"card-seo-twitter__link js-preview-domain\">
                            ";
                // line 47
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter($this->extensions['craft\web\twig\Extension']->replaceFilter(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 47, $this->source); })()), "helper", []), "siteUrl", [0 => "/"], "method"), ["http://" => ""]), ["https://" => ""]), ["/" => ""]), "html", null, true);
                echo "
                        </span>
                    </div>
                </a>
            </div>
        ";
            }
            // line 53
            echo "            <script type=\"text/javascript\">
                var x = document.getElementsByClassName(\"";
            // line 54
            echo twig_escape_filter($this->env, (isset($context["previewElementId"]) || array_key_exists("previewElementId", $context) ? $context["previewElementId"] : (function () { throw new RuntimeError('Variable "previewElementId" does not exist.', 54, $this->source); })()), "html", null, true);
            echo "-TwitterCard-image-wrapper\");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.backgroundImage = \"url('\" + \"";
            // line 57
            echo twig_escape_filter($this->env, ((isset($context["baseAssetsUrl"]) || array_key_exists("baseAssetsUrl", $context) ? $context["baseAssetsUrl"] : (function () { throw new RuntimeError('Variable "baseAssetsUrl" does not exist.', 57, $this->source); })()) . "/img/no_image_set.png"), "html", null, true);
            echo "\" + \"')\";
                    ";
            // line 58
            if ((craft\helpers\Template::attribute($this->env, $this->source, ($context["twitterImageArray"] ?? null), "content", [], "any", true, true) && $this->extensions['craft\web\twig\Extension']->lengthFilter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["twitterImageArray"]) || array_key_exists("twitterImageArray", $context) ? $context["twitterImageArray"] : (function () { throw new RuntimeError('Variable "twitterImageArray" does not exist.', 58, $this->source); })()), "content", [])))) {
                // line 59
                echo "                    ";
                $context["cacheBustString"] = "";
                // line 60
                echo "                    x[i].style.backgroundImage = \"url('\" + \"";
                echo (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["twitterImageArray"]) || array_key_exists("twitterImageArray", $context) ? $context["twitterImageArray"] : (function () { throw new RuntimeError('Variable "twitterImageArray" does not exist.', 60, $this->source); })()), "content", []) . (isset($context["cacheBustString"]) || array_key_exists("cacheBustString", $context) ? $context["cacheBustString"] : (function () { throw new RuntimeError('Variable "cacheBustString" does not exist.', 60, $this->source); })()));
                echo "\" + \"')\";
                    ";
            }
            // line 62
            echo "                }
            </script>
        ";
        } else {
            // line 65
            echo "            ";
            if (( !array_key_exists("previewContext", $context) || ((isset($context["previewContext"]) || array_key_exists("previewContext", $context) ? $context["previewContext"] : (function () { throw new RuntimeError('Variable "previewContext" does not exist.', 65, $this->source); })()) != "sidebar"))) {
                // line 66
                echo "                <div class=\"field\">
                    <p class=\"warning\">No Twitter Handle has been set. <a href=\"";
                // line 67
                echo twig_escape_filter($this->env, craft\helpers\UrlHelper::cpUrl("seomatic/site/social"), "html", null, true);
                echo "\">Set it here.</a></p>
                </div>
            ";
            }
            // line 70
            echo "        ";
        }
        // line 71
        echo "    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "seomatic/_includes/twitterPreview.twig");
    }

    public function getTemplateName()
    {
        return "seomatic/_includes/twitterPreview.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  196 => 71,  193 => 70,  187 => 67,  184 => 66,  181 => 65,  176 => 62,  170 => 60,  167 => 59,  165 => 58,  161 => 57,  155 => 54,  152 => 53,  143 => 47,  137 => 44,  131 => 41,  125 => 38,  121 => 37,  118 => 36,  109 => 30,  103 => 27,  97 => 24,  91 => 21,  87 => 20,  84 => 19,  81 => 18,  78 => 17,  75 => 16,  72 => 15,  69 => 14,  66 => 13,  62 => 11,  60 => 10,  56 => 9,  53 => 8,  51 => 7,  49 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set twitterTitleArray = seomatic.tag.get('twitter:title').renderAttributes() %}
{% set twitterDescriptionArray = seomatic.tag.get('twitter:description').renderAttributes() %}
{% set twitterImageArray = seomatic.tag.get('twitter:image').renderAttributes() %}
{% set canonicalArray = seomatic.link.get('canonical').renderAttributes() %}

{% set showSeoTitleNames = showSeoTitleNames ?? true %}
{% set previewElementId = previewElementId ?? 0 %}
<div class=\"preview-column\">
    <div class=\"displaypreview\" style=\"{{ displayPreviewInlineStyles ?? '' }}\">
        {% if showSeoTitleNames %}
            <h4 class=\"metadata-title-separator\"><span>Twitter</span></h4>
        {% endif %}
        {% if seomatic.site.twitterHandle |length %}
            {% set lg = false %}
            {% if seomatic.meta.twitterCard == \"summary_large_image\" %}
                {% set lg = true %}
            {% endif %}
            {% if lg %}
            <div class=\"card-seo-twitter\">
                <a class=\"seo-card-wrapper-link\" href=\"{{ canonicalArray.href ?? seomatic.helper.siteUrl(\"/\") }}\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-twitter__image js-preview-image {{ previewElementId }}-TwitterCard-image-wrapper\"></div>
                    <div class=\"card-seo-twitter__text\">
                        <span class=\"card-seo-twitter__title js-preview-title\">
                            {{ (twitterTitleArray.content ?? \"\") }}
                        </span>
                        <span class=\"card-seo-twitter__description js-preview-description\">
                            {{ (twitterDescriptionArray.content ?? \"\") }}
                        </span>
                        <span class=\"card-seo-twitter__link js-preview-domain\">
                            {{ seomatic.helper.siteUrl(\"/\") | replace({'http://': ''}) | replace({'https://': ''})  | replace({'/': ''}) }}
                        </span>
                    </div>
                </a>
            </div>
            {% else %}
            <div class=\"card-seo-twitter\">
                <a class=\"seo-card-wrapper-link\" href=\"{{ canonicalArray.href ?? seomatic.helper.siteUrl(\"/\") }}\" rel=\"noopener\" target=\"_blank\">
                    <div class=\"card-seo-twitter__image js-preview-image card-seo-twitter__image-summary {{ previewElementId }}-TwitterCard-image-wrapper\"></div>
                    <div class=\"card-seo-twitter__text card-seo-twitter__text-summary\">
                        <span class=\"card-seo-twitter__title js-preview-title\">
                            {{ (twitterTitleArray.content ?? \"\") }}
                        </span>
                        <span class=\"card-seo-twitter__description card-seo-twitter__description-summary js-preview-description\">
                            {{ (twitterDescriptionArray.content ?? \"\") }}
                        </span>
                        <span class=\"card-seo-twitter__link js-preview-domain\">
                            {{ seomatic.helper.siteUrl(\"/\") | replace({'http://': ''}) | replace({'https://': ''})  | replace({'/': ''}) }}
                        </span>
                    </div>
                </a>
            </div>
        {% endif %}
            <script type=\"text/javascript\">
                var x = document.getElementsByClassName(\"{{ previewElementId }}-TwitterCard-image-wrapper\");
                var i;
                for (i = 0; i < x.length; i++) {
                    x[i].style.backgroundImage = \"url('\" + \"{{ baseAssetsUrl ~ '/img/no_image_set.png' }}\" + \"')\";
                    {% if twitterImageArray.content is defined and twitterImageArray.content |length %}
                    {% set cacheBustString = \"\" %}
                    x[i].style.backgroundImage = \"url('\" + \"{{ (twitterImageArray.content ~ cacheBustString) | raw }}\" + \"')\";
                    {% endif %}
                }
            </script>
        {% else %}
            {% if previewContext is not defined or previewContext != \"sidebar\" %}
                <div class=\"field\">
                    <p class=\"warning\">No Twitter Handle has been set. <a href=\"{{ cpUrl(\"seomatic/site/social\") }}\">Set it here.</a></p>
                </div>
            {% endif %}
        {% endif %}
    </div>
</div>
", "seomatic/_includes/twitterPreview.twig", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/nystudio107/craft-seomatic/src/templates/_includes/twitterPreview.twig");
    }
}
