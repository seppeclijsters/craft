<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__6d3f4a29f0102c171a103ce1fd7f2957cc5d7b9f7466f8be78b6fb6095000453 */
class __TwigTemplate_6a9d8734eb00ac5847324114a71fc0b7c932a4c95de1d0dbd95b82518820dc55 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__6d3f4a29f0102c171a103ce1fd7f2957cc5d7b9f7466f8be78b6fb6095000453");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, ($context["entry"] ?? null), "url", []);
        craft\helpers\Template::endProfile("template", "__string_template__6d3f4a29f0102c171a103ce1fd7f2957cc5d7b9f7466f8be78b6fb6095000453");
    }

    public function getTemplateName()
    {
        return "__string_template__6d3f4a29f0102c171a103ce1fd7f2957cc5d7b9f7466f8be78b6fb6095000453";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ entry.url }}", "__string_template__6d3f4a29f0102c171a103ce1fd7f2957cc5d7b9f7466f8be78b6fb6095000453", "");
    }
}
