<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__5d414aa4995f52d2bbc81f38d87af95c46f33e3f2b696d7cfa8ef94310837d18 */
class __TwigTemplate_8540f03ecd861cbba2101f593033599533badc7b9faa1f1a698ba066ad1158cf extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__5d414aa4995f52d2bbc81f38d87af95c46f33e3f2b696d7cfa8ef94310837d18");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "seoTitle", []);
        craft\helpers\Template::endProfile("template", "__string_template__5d414aa4995f52d2bbc81f38d87af95c46f33e3f2b696d7cfa8ef94310837d18");
    }

    public function getTemplateName()
    {
        return "__string_template__5d414aa4995f52d2bbc81f38d87af95c46f33e3f2b696d7cfa8ef94310837d18";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.seoTitle }}", "__string_template__5d414aa4995f52d2bbc81f38d87af95c46f33e3f2b696d7cfa8ef94310837d18", "");
    }
}
