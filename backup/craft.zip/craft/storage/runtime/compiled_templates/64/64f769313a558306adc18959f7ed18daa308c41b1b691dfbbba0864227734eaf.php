<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__365a23efdd549386c20c5b4e1de6f16cd444779aef3d6785a3a8d3742cc2c272 */
class __TwigTemplate_9ccb81f213584434459c7f6be1c6f0a7807f848d96e812f1d7ab9311360e16e1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__365a23efdd549386c20c5b4e1de6f16cd444779aef3d6785a3a8d3742cc2c272");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "seoImageDescription", []);
        craft\helpers\Template::endProfile("template", "__string_template__365a23efdd549386c20c5b4e1de6f16cd444779aef3d6785a3a8d3742cc2c272");
    }

    public function getTemplateName()
    {
        return "__string_template__365a23efdd549386c20c5b4e1de6f16cd444779aef3d6785a3a8d3742cc2c272";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.seoImageDescription }}", "__string_template__365a23efdd549386c20c5b4e1de6f16cd444779aef3d6785a3a8d3742cc2c272", "");
    }
}
