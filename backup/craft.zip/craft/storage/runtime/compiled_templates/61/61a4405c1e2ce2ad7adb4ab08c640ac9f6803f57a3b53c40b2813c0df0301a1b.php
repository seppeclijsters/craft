<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _layouts/components/global-sidebar */
class __TwigTemplate_5d689ed52a5b9b5dbb7dd1abc8d2b4bbb9ba35ba39e1be897df27232fccb4efa extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_layouts/components/global-sidebar");
        // line 1
        echo "<header id=\"global-sidebar\" class=\"sidebar\">
    <a id=\"system-info\" href=\"";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["siteUrl"]) || array_key_exists("siteUrl", $context) ? $context["siteUrl"] : (function () { throw new RuntimeError('Variable "siteUrl" does not exist.', 2, $this->source); })()), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\" title=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("View site", "app"), "html", null, true);
        echo "\" aria-label=\"";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("View site", "app"), "html", null, true);
        echo "\">
        <div id=\"site-icon\">
            ";
        // line 4
        if ((isset($context["hasSystemIcon"]) || array_key_exists("hasSystemIcon", $context) ? $context["hasSystemIcon"] : (function () { throw new RuntimeError('Variable "hasSystemIcon" does not exist.', 4, $this->source); })())) {
            // line 5
            echo "                <img src=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 5, $this->source); })()), "rebrand", []), "icon", []), "url", []), "html", null, true);
            echo "\" alt=\"\">
            ";
        } else {
            // line 7
            echo "                ";
            echo $this->extensions['craft\web\twig\Extension']->svgFunction("@appicons/c-outline.svg", null, true);
            echo "
            ";
        }
        // line 9
        echo "        </div>
        <div id=\"system-name\">
            <span class=\"h2\">";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["systemName"]) || array_key_exists("systemName", $context) ? $context["systemName"] : (function () { throw new RuntimeError('Variable "systemName" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "</span>
        </div>
    </a>

    <nav id=\"nav\" aria-label=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Primary", "app"), "html", null, true);
        echo "\">
        <ul>
            ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 17, $this->source); })()), "cp", []), "nav", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 18
            echo "                ";
            $context["itemAttributes"] = ["id" => craft\helpers\Template::attribute($this->env, $this->source,             // line 19
$context["item"], "id", []), "class" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 20
$context["item"], "subnav", [])) ? ("has-subnav") : (""))];
            // line 22
            echo "                ";
            $context["linkAttributes"] = ["href" => craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->source,             // line 23
$context["item"], "url", [])), "class" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 24
$context["item"], "sel", [])) ? ("sel") : ("")), "aria" => ["current" => (((craft\helpers\Template::attribute($this->env, $this->source,             // line 26
$context["item"], "sel", []) &&  !craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", []))) ? ("page") : (false))]];
            // line 29
            echo "                <li ";
            echo craft\helpers\Html::renderTagAttributes((isset($context["itemAttributes"]) || array_key_exists("itemAttributes", $context) ? $context["itemAttributes"] : (function () { throw new RuntimeError('Variable "itemAttributes" does not exist.', 29, $this->source); })()));
            echo ">
                    <a ";
            // line 30
            echo craft\helpers\Html::renderTagAttributes((isset($context["linkAttributes"]) || array_key_exists("linkAttributes", $context) ? $context["linkAttributes"] : (function () { throw new RuntimeError('Variable "linkAttributes" does not exist.', 30, $this->source); })()));
            echo ">
                        <span class=\"icon icon-mask\" aria-hidden=\"true\">";
            // line 32
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "icon", [], "any", true, true)) {
                // line 33
                echo $this->extensions['craft\web\twig\Extension']->svgFunction(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "icon", []), true, true);
            } elseif (craft\helpers\Template::attribute($this->env, $this->source,             // line 34
$context["item"], "fontIcon", [], "any", true, true)) {
                // line 35
                echo "<span data-icon=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "fontIcon", []), "html", null, true);
                echo "\"></span>";
            } else {
                // line 37
                $this->loadTemplate("_includes/defaulticon.svg.twig", "_layouts/components/global-sidebar", 37)->display(twig_array_merge($context, ["label" => craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", [])]));
            }
            // line 39
            echo "</span>

                        <span class=\"label\">";
            // line 41
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", []), "html", null, true);
            echo "</span>";
            // line 43
            if (( !craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "sel", []) && craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "badgeCount", []))) {
                // line 44
                echo "<span class=\"badge\" aria-hidden=\"true\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "badgeCount", []), 0), "html", null, true);
                echo "</span>
                            ";
                // line 45
                echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 51
$context["item"], "badgeCount", [])])]);
            }
            // line 55
            echo "</a>
                    ";
            // line 56
            if (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", [])) {
                // line 57
                echo "                        <ul class=\"subnav\">
                            ";
                // line 58
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "subnav", []));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["itemId"] => $context["item"]) {
                    // line 59
                    echo "                                ";
                    $context["itemIsSelected"] = ((                    // line 60
array_key_exists("selectedSubnavItem", $context) && ((isset($context["selectedSubnavItem"]) || array_key_exists("selectedSubnavItem", $context) ? $context["selectedSubnavItem"] : (function () { throw new RuntimeError('Variable "selectedSubnavItem" does not exist.', 60, $this->source); })()) == $context["itemId"])) || ( !                    // line 61
array_key_exists("selectedSubnavItem", $context) && craft\helpers\Template::attribute($this->env, $this->source, $context["loop"], "first", [])));
                    // line 63
                    $context["linkAttributes"] = ["href" => craft\helpers\UrlHelper::url(craft\helpers\Template::attribute($this->env, $this->source,                     // line 64
$context["item"], "url", [])), "class" => [0 => ((                    // line 66
(isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 66, $this->source); })())) ? ("sel") : ("")), 1 => (((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 67
$context["item"], "external", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "external", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "external", [])) : (false))) ? ("external") : (""))], "target" => (((((craft\helpers\Template::attribute($this->env, $this->source,                     // line 69
$context["item"], "external", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "external", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "external", [])) : (false))) ? ("_blank") : ("")), "aria" => ["current" => ((                    // line 71
(isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 71, $this->source); })())) ? ("page") : (false))]];
                    // line 74
                    echo "
                                <li>
                                    <a ";
                    // line 76
                    echo craft\helpers\Html::renderTagAttributes((isset($context["linkAttributes"]) || array_key_exists("linkAttributes", $context) ? $context["linkAttributes"] : (function () { throw new RuntimeError('Variable "linkAttributes" does not exist.', 76, $this->source); })()));
                    echo ">
                                        ";
                    // line 77
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "label", []), "html", null, true);
                    // line 79
                    if (( !(isset($context["itemIsSelected"]) || array_key_exists("itemIsSelected", $context) ? $context["itemIsSelected"] : (function () { throw new RuntimeError('Variable "itemIsSelected" does not exist.', 79, $this->source); })()) && craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "badgeCount", [], "any", true, true))) {
                        // line 80
                        echo "<span class=\"badge\" aria-hidden=\"true\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->numberFilter(craft\helpers\Template::attribute($this->env, $this->source, $context["item"], "badgeCount", []), 0), "html", null, true);
                        echo "</span>
                                            ";
                        // line 81
                        echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "data" => ["notification" => true], "text" => $this->extensions['craft\web\twig\Extension']->translateFilter("{num, number} {num, plural, =1{notification} other{notifications}}", "app", ["num" => craft\helpers\Template::attribute($this->env, $this->source,                         // line 87
$context["item"], "badgeCount", [])])]);
                    }
                    // line 91
                    echo "</a>
                                </li>
                            ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['itemId'], $context['item'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 94
                echo "                        </ul>
                    ";
            }
            // line 96
            echo "                </li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "        </ul>
    </nav>

    ";
        // line 101
        if ((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["currentUser"]) || array_key_exists("currentUser", $context) ? $context["currentUser"] : (function () { throw new RuntimeError('Variable "currentUser" does not exist.', 101, $this->source); })()), "admin", []) && (isset($context["devMode"]) || array_key_exists("devMode", $context) ? $context["devMode"] : (function () { throw new RuntimeError('Variable "devMode" does not exist.', 101, $this->source); })()))) {
            // line 102
            echo "        ";
            $context["devModeText"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Craft CMS is running in Dev Mode.", "app");
            // line 103
            echo "        <div id=\"devmode\">
            ";
            // line 104
            echo $this->extensions['craft\web\twig\Extension']->tagFunction("span", ["class" => "visually-hidden", "text" =>             // line 106
(isset($context["devModeText"]) || array_key_exists("devModeText", $context) ? $context["devModeText"] : (function () { throw new RuntimeError('Variable "devModeText" does not exist.', 106, $this->source); })())]);
            // line 107
            echo "
        </div>
    ";
        }
        // line 110
        echo "</header>
";
        craft\helpers\Template::endProfile("template", "_layouts/components/global-sidebar");
    }

    public function getTemplateName()
    {
        return "_layouts/components/global-sidebar";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  263 => 110,  258 => 107,  256 => 106,  255 => 104,  252 => 103,  249 => 102,  247 => 101,  242 => 98,  227 => 96,  223 => 94,  207 => 91,  204 => 87,  203 => 81,  198 => 80,  196 => 79,  194 => 77,  190 => 76,  186 => 74,  184 => 71,  183 => 69,  182 => 67,  181 => 66,  180 => 64,  179 => 63,  177 => 61,  176 => 60,  174 => 59,  157 => 58,  154 => 57,  152 => 56,  149 => 55,  146 => 51,  145 => 45,  140 => 44,  138 => 43,  135 => 41,  131 => 39,  128 => 37,  123 => 35,  121 => 34,  119 => 33,  117 => 32,  113 => 30,  108 => 29,  106 => 26,  105 => 24,  104 => 23,  102 => 22,  100 => 20,  99 => 19,  97 => 18,  80 => 17,  75 => 15,  68 => 11,  64 => 9,  58 => 7,  52 => 5,  50 => 4,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<header id=\"global-sidebar\" class=\"sidebar\">
    <a id=\"system-info\" href=\"{{ siteUrl }}\" rel=\"noopener\" target=\"_blank\" title=\"{{ 'View site'|t('app') }}\" aria-label=\"{{ 'View site'|t('app') }}\">
        <div id=\"site-icon\">
            {% if hasSystemIcon %}
                <img src=\"{{ craft.rebrand.icon.url }}\" alt=\"\">
            {% else %}
                {{ svg('@appicons/c-outline.svg', namespace=true) }}
            {% endif %}
        </div>
        <div id=\"system-name\">
            <span class=\"h2\">{{ systemName }}</span>
        </div>
    </a>

    <nav id=\"nav\" aria-label=\"{{ 'Primary'|t('app') }}\">
        <ul>
            {% for item in craft.cp.nav() %}
                {% set itemAttributes = {
                    id: item.id,
                    class: item.subnav ? 'has-subnav',
                } %}
                {% set linkAttributes = {
                    href: url(item.url),
                    class: item.sel ? 'sel',
                    aria: {
                        current: item.sel and not item.subnav ? 'page' : false,
                    },
                } %}
                <li {{ attr(itemAttributes) }}>
                    <a {{ attr(linkAttributes) }}>
                        <span class=\"icon icon-mask\" aria-hidden=\"true\">
                            {%- if item.icon is defined -%}
                                {{ svg(item.icon, sanitize=true, namespace=true) }}
                            {%- elseif item.fontIcon is defined -%}
                                <span data-icon=\"{{ item.fontIcon }}\"></span>
                            {%- else -%}
                                {% include \"_includes/defaulticon.svg.twig\" with { label: item.label } %}
                            {%- endif -%}
                        </span>

                        <span class=\"label\">{{ item.label }}</span>

                        {%- if not item.sel and item.badgeCount -%}
                            <span class=\"badge\" aria-hidden=\"true\">{{ item.badgeCount|number(decimals=0) }}</span>
                            {{ tag('span', {
                                class: 'visually-hidden',
                                data: {
                                    notification: true,
                                },
                                text: '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                                    num: item.badgeCount,
                                }),
                            }) }}
                        {%- endif -%}
                    </a>
                    {% if item.subnav %}
                        <ul class=\"subnav\">
                            {% for itemId, item in item.subnav %}
                                {% set itemIsSelected = (
                                    (selectedSubnavItem is defined and selectedSubnavItem == itemId) or
                                    (selectedSubnavItem is not defined and loop.first)
                                ) -%}
                                {% set linkAttributes = {
                                    href: url(item.url),
                                    class: [
                                        itemIsSelected ? 'sel',
                                        (item.external ?? false) ? 'external',
                                    ],
                                    target: (item.external ?? false) ? '_blank',
                                    aria: {
                                        current: itemIsSelected ? 'page' : false,
                                    },
                                } %}

                                <li>
                                    <a {{ attr(linkAttributes) }}>
                                        {{ item.label }}

                                        {%- if not itemIsSelected and item.badgeCount is defined -%}
                                            <span class=\"badge\" aria-hidden=\"true\">{{ item.badgeCount|number(decimals=0) }}</span>
                                            {{ tag('span', {
                                                class: 'visually-hidden',
                                                data: {
                                                    notification: true,
                                                },
                                                text: '{num, number} {num, plural, =1{notification} other{notifications}}'|t('app', {
                                                    num: item.badgeCount,
                                                }),
                                            }) }}
                                        {%- endif -%}
                                    </a>
                                </li>
                            {% endfor %}
                        </ul>
                    {% endif %}
                </li>
            {% endfor %}
        </ul>
    </nav>

    {% if currentUser.admin and devMode %}
        {% set devModeText = 'Craft CMS is running in Dev Mode.'|t('app') %}
        <div id=\"devmode\">
            {{ tag('span', {
                class: 'visually-hidden',
                text: devModeText
            }) }}
        </div>
    {% endif %}
</header>
", "_layouts/components/global-sidebar", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_layouts/components/global-sidebar.twig");
    }
}
