<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__eb7de5ba0b5a06f7a5b80a2a609eef1ca1d97316636d6ea1fd537ce4000f7b45 */
class __TwigTemplate_2a80d520bb696052174f5fd77d4316461ff56bf098657e7138bb680972ce460b extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__eb7de5ba0b5a06f7a5b80a2a609eef1ca1d97316636d6ea1fd537ce4000f7b45");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "config", []), "separatorChar", []);
        craft\helpers\Template::endProfile("template", "__string_template__eb7de5ba0b5a06f7a5b80a2a609eef1ca1d97316636d6ea1fd537ce4000f7b45");
    }

    public function getTemplateName()
    {
        return "__string_template__eb7de5ba0b5a06f7a5b80a2a609eef1ca1d97316636d6ea1fd537ce4000f7b45";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.config.separatorChar }}", "__string_template__eb7de5ba0b5a06f7a5b80a2a609eef1ca1d97316636d6ea1fd537ce4000f7b45", "");
    }
}
