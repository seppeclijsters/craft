<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* seomatic/_sidebars/entry-preview.twig */
class __TwigTemplate_d0883f972885541d986e2abb5caa8143923ba9807d0f080f8872b8c44e4b263a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "seomatic/_sidebars/entry-preview.twig");
        // line 1
        $this->loadTemplate("seomatic/_sidebars/_includes/sidebar-preview.twig", "seomatic/_sidebars/entry-preview.twig", 1)->display(twig_array_merge($context, ["previewContext" => "sidebar"]));
        craft\helpers\Template::endProfile("template", "seomatic/_sidebars/entry-preview.twig");
    }

    public function getTemplateName()
    {
        return "seomatic/_sidebars/entry-preview.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% include \"seomatic/_sidebars/_includes/sidebar-preview.twig\" with {\"previewContext\": \"sidebar\"} %}", "seomatic/_sidebars/entry-preview.twig", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/nystudio107/craft-seomatic/src/templates/_sidebars/entry-preview.twig");
    }
}
