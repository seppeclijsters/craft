<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/date */
class __TwigTemplate_3b7138e6c2ca79f7227524a38db23a10afd13b8ff5a85f94f8412bf90ef8774a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/date");
        // line 1
        $context["hasOuterContainer"] = (($context["hasOuterContainer"]) ?? (false));
        // line 2
        $context["id"] = ((($context["id"]) ?? (("date" . twig_random($this->env)))) . "-date");
        // line 3
        $context["name"] = (($context["name"]) ?? (null));
        // line 4
        $context["value"] = (((($context["value"]) ?? (false))) ? ($this->extensions['craft\web\twig\Extension']->dateFunction($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 4, $this->source); })()), false)) : (null));
        // line 5
        $context["outputTzParam"] = (($context["outputTzParam"]) ?? (true));
        // line 6
        $context["isMobile"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 6, $this->source); })()), "app", []), "request", []), "isMobileBrowser", []);
        // line 7
        $context["describedBy"] = (($context["describedBy"]) ?? (null));
        // line 8
        $context["isDateTime"] = (($context["isDateTime"]) ?? (false));
        // line 9
        echo "
";
        // line 10
        $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter(["class" => $this->extensions['craft\web\twig\Extension']->mergeFilter([0 => "datewrapper"], craft\helpers\Html::explodeClass(((        // line 11
$context["class"]) ?? ([]))))], ((        // line 12
$context["containerAttributes"]) ?? ([])), true);
        // line 14
        if (        $this->hasBlock("attr", $context, $blocks)) {
            // line 15
            $context["containerAttributes"] = $this->extensions['craft\web\twig\Extension']->mergeFilter((isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 15, $this->source); })()), $this->extensions['craft\web\twig\Extension']->parseAttrFilter((("<div " .             $this->renderBlock("attr", $context, $blocks)) . ">")), true);
        }
        // line 17
        echo "
";
        // line 18
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 18, $this->source); })())) {
            echo "<div class=\"datetimewrapper\">";
        }
        // line 19
        echo "
";
        // line 20
        ob_start();
        // line 21
        $this->loadTemplate("_includes/forms/text", "_includes/forms/date", 21)->display(twig_array_merge($context, ["type" => ((        // line 22
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 22, $this->source); })())) ? ("date") : ("text")), "class" => (((        // line 23
(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 23, $this->source); })()) &&  !(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 23, $this->source); })()))) ? ("empty-value") : (false)), "name" => ((        // line 24
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 24, $this->source); })())) ? (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 24, $this->source); })()) . "[date]")) : (null)), "autocomplete" => false, "size" => 10, "placeholder" => " ", "value" => ((        // line 28
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 28, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->dateFilter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 28, $this->source); })()), (((isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 28, $this->source); })())) ? ("Y-m-d") : ("short")))) : ("")), "inputAttributes" => ["aria" => ["label" => ((        // line 31
(isset($context["isDateTime"]) || array_key_exists("isDateTime", $context) ? $context["isDateTime"] : (function () { throw new RuntimeError('Variable "isDateTime" does not exist.', 31, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Date", "app")) : (false))]]]));
        // line 35
        echo "<div data-icon=\"date\"></div>";
        // line 36
        if (((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 36, $this->source); })()) && (isset($context["outputTzParam"]) || array_key_exists("outputTzParam", $context) ? $context["outputTzParam"] : (function () { throw new RuntimeError('Variable "outputTzParam" does not exist.', 36, $this->source); })()))) {
            // line 37
            echo craft\helpers\Html::hiddenInput(((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new RuntimeError('Variable "name" does not exist.', 37, $this->source); })()) . "[timezone]"), craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 37, $this->source); })()), "app", []), "getTimeZone", [], "method"));
        }
        echo craft\helpers\Html::tag("div", ob_get_clean(),         // line 20
(isset($context["containerAttributes"]) || array_key_exists("containerAttributes", $context) ? $context["containerAttributes"] : (function () { throw new RuntimeError('Variable "containerAttributes" does not exist.', 20, $this->source); })()));
        // line 40
        echo "
";
        // line 41
        if ( !(isset($context["hasOuterContainer"]) || array_key_exists("hasOuterContainer", $context) ? $context["hasOuterContainer"] : (function () { throw new RuntimeError('Variable "hasOuterContainer" does not exist.', 41, $this->source); })())) {
            echo "</div>";
        }
        // line 43
        if ( !(isset($context["isMobile"]) || array_key_exists("isMobile", $context) ? $context["isMobile"] : (function () { throw new RuntimeError('Variable "isMobile" does not exist.', 43, $this->source); })())) {
            // line 44
            ob_start();
            // line 45
            echo "\$('#";
            echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->env->getFilter('namespaceInputId')->getCallable()((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 45, $this->source); })())), "js"), "html", null, true);
            echo "').datepicker(\$.extend({
            defaultDate: new Date(";
            // line 46
            if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 46, $this->source); })())) {
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 46, $this->source); })()), "format", [0 => "Y"], "method"), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 46, $this->source); })()), "format", [0 => "n"], "method") - 1), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new RuntimeError('Variable "value" does not exist.', 46, $this->source); })()), "format", [0 => "j"], "method"), "html", null, true);
            }
            echo ")
        }, Craft.datepickerOptions));";
            craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        }
        craft\helpers\Template::endProfile("template", "_includes/forms/date");
    }

    public function getTemplateName()
    {
        return "_includes/forms/date";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 46,  105 => 45,  103 => 44,  101 => 43,  97 => 41,  94 => 40,  92 => 20,  89 => 37,  87 => 36,  85 => 35,  83 => 31,  82 => 28,  81 => 24,  80 => 23,  79 => 22,  78 => 21,  76 => 20,  73 => 19,  69 => 18,  66 => 17,  63 => 15,  61 => 14,  59 => 12,  58 => 11,  57 => 10,  54 => 9,  52 => 8,  50 => 7,  48 => 6,  46 => 5,  44 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% set hasOuterContainer = hasOuterContainer ?? false %}
{% set id = (id ?? \"date#{random()}\") ~ '-date' -%}
{% set name = name ?? null -%}
{% set value = (value ?? false) ? date(value, false) : null -%}
{% set outputTzParam = outputTzParam ?? true %}
{% set isMobile = craft.app.request.isMobileBrowser %}
{% set describedBy = describedBy ?? null %}
{% set isDateTime = isDateTime ?? false %}

{% set containerAttributes = {
    class: ['datewrapper']|merge((class ?? [])|explodeClass),
}|merge(containerAttributes ?? [], recursive=true) %}

{%- if block('attr') is defined %}
    {%- set containerAttributes = containerAttributes|merge(('<div ' ~ block('attr') ~ '>')|parseAttr, recursive=true) %}
{% endif %}

{% if not hasOuterContainer %}<div class=\"datetimewrapper\">{% endif %}

{% tag 'div' with containerAttributes %}
    {%- include \"_includes/forms/text\" with {
        type: isMobile ? 'date' : 'text',
        class: isMobile and not value ? 'empty-value' : false,
        name: name ? \"#{name}[date]\" : null,
        autocomplete: false,
        size: 10,
        placeholder: ' ',
        value: value ? value|date(isMobile ? 'Y-m-d' : 'short') : '',
        inputAttributes: {
            aria: {
                label: isDateTime ? 'Date'|t('app') : false,
            },
        },
    } -%}
    <div data-icon=\"date\"></div>
    {%- if name and outputTzParam -%}
        {{- hiddenInput(\"#{name}[timezone]\", craft.app.getTimeZone()) -}}
    {%- endif -%}
{% endtag %}

{% if not hasOuterContainer %}</div>{% endif %}

{%- if not isMobile -%}
    {%- js -%}
        \$('#{{ id|namespaceInputId|e('js') }}').datepicker(\$.extend({
            defaultDate: new Date({% if value %}{{ value.format('Y') }}, {{ value.format('n')-1 }}, {{ value.format('j') }}{% endif %})
        }, Craft.datepickerOptions));
    {%- endjs -%}
{%- endif -%}
", "_includes/forms/date", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_includes/forms/date.twig");
    }
}
