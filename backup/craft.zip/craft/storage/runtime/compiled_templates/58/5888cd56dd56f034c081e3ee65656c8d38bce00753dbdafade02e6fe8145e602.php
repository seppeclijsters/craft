<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__9cd62524c3f3d0dcafa0e08a97634b3b6c3161d0fc4a082fea918b3359984172 */
class __TwigTemplate_750599491c694ea9cd0cc1acac68f3cd0c47f7c4e915fd935d8c966bb9c4e08d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__9cd62524c3f3d0dcafa0e08a97634b3b6c3161d0fc4a082fea918b3359984172");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "seoDescription", []);
        craft\helpers\Template::endProfile("template", "__string_template__9cd62524c3f3d0dcafa0e08a97634b3b6c3161d0fc4a082fea918b3359984172");
    }

    public function getTemplateName()
    {
        return "__string_template__9cd62524c3f3d0dcafa0e08a97634b3b6c3161d0fc4a082fea918b3359984172";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.seoDescription }}", "__string_template__9cd62524c3f3d0dcafa0e08a97634b3b6c3161d0fc4a082fea918b3359984172", "");
    }
}
