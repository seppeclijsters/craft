<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__7617fa33f13829c2e77bd2439359adb1156768dc0b48501db5a653061c87f968 */
class __TwigTemplate_05aa11aa373f6978aaa2780cf8e5e7c73c848ec27e07ab3e589a5a8f31e041e1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__7617fa33f13829c2e77bd2439359adb1156768dc0b48501db5a653061c87f968");
        // line 1
        echo "prime";
        craft\helpers\Template::endProfile("template", "__string_template__7617fa33f13829c2e77bd2439359adb1156768dc0b48501db5a653061c87f968");
    }

    public function getTemplateName()
    {
        return "__string_template__7617fa33f13829c2e77bd2439359adb1156768dc0b48501db5a653061c87f968";
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ \"prime\" }}", "__string_template__7617fa33f13829c2e77bd2439359adb1156768dc0b48501db5a653061c87f968", "");
    }
}
