<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__e00d7f8daee9d24b2c52d03d13e3c4acc7bb2f95065563f53a9929cbcc6825df */
class __TwigTemplate_d15ee20db09e0130203248e9b3c833ec105d114bf2dd58f17f5fe8a3a3c880f7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__e00d7f8daee9d24b2c52d03d13e3c4acc7bb2f95065563f53a9929cbcc6825df");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "mainEntityOfPage", []);
        craft\helpers\Template::endProfile("template", "__string_template__e00d7f8daee9d24b2c52d03d13e3c4acc7bb2f95065563f53a9929cbcc6825df");
    }

    public function getTemplateName()
    {
        return "__string_template__e00d7f8daee9d24b2c52d03d13e3c4acc7bb2f95065563f53a9929cbcc6825df";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.mainEntityOfPage }}", "__string_template__e00d7f8daee9d24b2c52d03d13e3c4acc7bb2f95065563f53a9929cbcc6825df", "");
    }
}
