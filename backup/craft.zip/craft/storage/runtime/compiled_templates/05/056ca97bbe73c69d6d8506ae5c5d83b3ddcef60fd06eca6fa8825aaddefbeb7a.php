<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* graphql/schemas/_edit */
class __TwigTemplate_96404b77aa9ba0f54c0e64c73a9bbd4e1607a91662bd3324a4b7419e74956b9f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
            'details' => [$this, 'block_details'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "graphql/schemas/_edit");
        // line 3
        if (\Craft::$app->getEdition() < (isset($context["CraftPro"]) || array_key_exists("CraftPro", $context) ? $context["CraftPro"] : (function () { throw new RuntimeError('Variable "CraftPro" does not exist.', 3, $this->source); })()))
        {
            throw new yii\web\NotFoundHttpException;
        }
        // line 5
        $context["selectedSubnavItem"] = "schemas";
        // line 7
        $context["fullPageForm"] = true;
        // line 9
        $context["crumbs"] = [0 => ["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("GraphQL Schemas", "app"), "url" => craft\helpers\UrlHelper::url("graphql/schemas")]];
        // line 13
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "graphql/schemas/_edit", 13)->unwrap();
        // line 54
        $macros["__internal_parse_2"] = $this->macros["__internal_parse_2"] = $this;
        // line 56
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 56, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Select All", 1 => "Deselect All"]], "method");
        // line 61
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 61, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\userpermissions\\UserPermissionsAsset"], "method");
        // line 133
        ob_start();
        // line 134
        echo "    new Craft.ElevatedSessionForm('#main-form');
";
        craft\helpers\Template::js(ob_get_clean(), ['position' => 3]);
        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "graphql/schemas/_edit", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        craft\helpers\Template::endProfile("template", "graphql/schemas/_edit");
    }

    // line 63
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "content");
        // line 64
        echo "    ";
        echo craft\helpers\Html::actionInput(((craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 64, $this->source); })()), "isPublic", [])) ? ("graphql/save-public-schema") : ("graphql/save-schema")));
        echo "
    ";
        // line 65
        echo craft\helpers\Html::redirectInput("graphql/schemas");
        echo "
    ";
        // line 66
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 66, $this->source); })()), "id", [])) {
            echo craft\helpers\Html::hiddenInput("schemaId", craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 66, $this->source); })()), "id", []));
        }
        // line 67
        echo "
    ";
        // line 68
        if ( !craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 68, $this->source); })()), "isPublic", [])) {
            // line 69
            echo "        ";
            echo twig_call_macro($macros["forms"], "macro_textField", [["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this schema will be called in the control panel.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->source,             // line 75
(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 75, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 76
(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 76, $this->source); })()), "getErrors", [0 => "name"], "method"), "autofocus" => true, "required" => true]], 69, $context, $this->getSourceContext());
            // line 79
            echo "

        <hr>
    ";
        }
        // line 83
        echo "
    <h2>";
        // line 84
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Choose the available content for querying with this schema:", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 86
        $context["schemaComponents"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new RuntimeError('Variable "craft" does not exist.', 86, $this->source); })()), "app", []), "gql", []), "getAllSchemaComponents", []);
        // line 87
        echo "
    ";
        // line 88
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schemaComponents"]) || array_key_exists("schemaComponents", $context) ? $context["schemaComponents"] : (function () { throw new RuntimeError('Variable "schemaComponents" does not exist.', 88, $this->source); })()), "queries", []));
        foreach ($context['_seq'] as $context["category"] => $context["catPermissions"]) {
            // line 89
            echo "        <div class=\"user-permissions\">
            <h3>";
            // line 90
            echo twig_escape_filter($this->env, $context["category"], "html", null, true);
            echo "</h3>
            <div class=\"select-all\"></div>

            ";
            // line 93
            echo twig_call_macro($macros["__internal_parse_2"], "macro_permissionList", [(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 93, $this->source); })()), $context["catPermissions"]], 93, $context, $this->getSourceContext());
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['category'], $context['catPermissions'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 96
        echo "
    <hr/>
    <h2>";
        // line 98
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Choose the available mutations for this schema:", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 100
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schemaComponents"]) || array_key_exists("schemaComponents", $context) ? $context["schemaComponents"] : (function () { throw new RuntimeError('Variable "schemaComponents" does not exist.', 100, $this->source); })()), "mutations", []));
        foreach ($context['_seq'] as $context["category"] => $context["catPermissions"]) {
            // line 101
            echo "        <div class=\"user-permissions\">
            <h3>";
            // line 102
            echo twig_escape_filter($this->env, $context["category"], "html", null, true);
            echo "</h3>
            <div class=\"select-all\"></div>

            ";
            // line 105
            echo twig_call_macro($macros["__internal_parse_2"], "macro_permissionList", [(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 105, $this->source); })()), $context["catPermissions"]], 105, $context, $this->getSourceContext());
            echo "
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['category'], $context['catPermissions'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 108
        echo "

";
        craft\helpers\Template::endProfile("block", "content");
    }

    // line 112
    public function block_details($context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("block", "details");
        // line 113
        echo "    ";
        if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 113, $this->source); })()), "isPublic", [])) {
            // line 114
            echo "        <div class=\"meta\">
            ";
            // line 115
            echo twig_call_macro($macros["forms"], "macro_lightswitchField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enabled", "app"), "id" => "enabled", "name" => "enabled", "on" => craft\helpers\Template::attribute($this->env, $this->source,             // line 119
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 119, $this->source); })()), "enabled", [])]], 115, $context, $this->getSourceContext());
            // line 120
            echo "

            ";
            // line 122
            echo twig_call_macro($macros["forms"], "macro_dateTimeField", [["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Expiry Date", "app"), "id" => "expiryDate", "name" => "expiryDate", "value" => ((craft\helpers\Template::attribute($this->env, $this->source,             // line 126
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 126, $this->source); })()), "expiryDate", [])) ? (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 126, $this->source); })()), "expiryDate", [])) : (null)), "errors" => craft\helpers\Template::attribute($this->env, $this->source,             // line 127
(isset($context["token"]) || array_key_exists("token", $context) ? $context["token"] : (function () { throw new RuntimeError('Variable "token" does not exist.', 127, $this->source); })()), "getErrors", [0 => "expiryDate"], "method")]], 122, $context, $this->getSourceContext());
            // line 128
            echo "
        </div>
    ";
        }
        craft\helpers\Template::endProfile("block", "details");
    }

    // line 15
    public function macro_permissionList($__schema__ = null, $__permissions__ = null, $__id__ = null, $__disabled__ = null, ...$__varargs__)
    {
        $macros = $this->macros;
        $context = $this->env->mergeGlobals([
            "schema" => $__schema__,
            "permissions" => $__permissions__,
            "id" => $__id__,
            "disabled" => $__disabled__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            craft\helpers\Template::beginProfile("macro", "permissionList");
            // line 16
            echo "
    ";
            // line 17
            $macros["__internal_parse_0"] = $this->loadTemplate("_includes/forms", "graphql/schemas/_edit", 17)->unwrap();
            // line 18
            echo "    ";
            $macros["__internal_parse_1"] = $this;
            // line 19
            echo "
    <ul";
            // line 20
            if ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 20, $this->source); })())) {
                echo " id=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->replaceFilter((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new RuntimeError('Variable "id" does not exist.', 20, $this->source); })()), ":", "-"), "html", null, true);
                echo "\"";
            }
            echo ">

        ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["permissions"]) || array_key_exists("permissions", $context) ? $context["permissions"] : (function () { throw new RuntimeError('Variable "permissions" does not exist.', 22, $this->source); })()));
            foreach ($context['_seq'] as $context["permissionName"] => $context["props"]) {
                // line 23
                echo "            ";
                if (craft\helpers\Template::attribute($this->env, $this->source, (isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 23, $this->source); })()), "has", [0 => $context["permissionName"]], "method")) {
                    // line 24
                    echo "                ";
                    $context["checked"] = true;
                    // line 25
                    echo "            ";
                } else {
                    // line 26
                    echo "                ";
                    $context["checked"] = false;
                    // line 27
                    echo "            ";
                }
                // line 28
                echo "
            <li>
                ";
                // line 30
                echo twig_call_macro($macros["__internal_parse_0"], "macro_checkbox", [["label" => craft\helpers\Template::attribute($this->env, $this->source,                 // line 31
$context["props"], "label", []), "name" => "permissions[]", "value" =>                 // line 33
$context["permissionName"], "checked" =>                 // line 34
(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 34, $this->source); })()), "disabled" =>                 // line 35
(isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new RuntimeError('Variable "disabled" does not exist.', 35, $this->source); })())]], 30, $context, $this->getSourceContext());
                // line 36
                echo "

                ";
                // line 38
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", [])) : (false))) {
                    // line 39
                    echo "                    <div class=\"info\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "info", []), "html", null, true);
                    echo "</div>
                ";
                }
                // line 41
                echo "
                ";
                // line 42
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", [])) : (false))) {
                    // line 43
                    echo "                    <div class=\"info warning\">";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "warning", []), "html", null, true);
                    echo "</div>
                ";
                }
                // line 45
                echo "
                ";
                // line 46
                if ((((craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", [])) : (false))) {
                    // line 47
                    echo "                    ";
                    echo twig_call_macro($macros["__internal_parse_1"], "macro_permissionList", [(isset($context["schema"]) || array_key_exists("schema", $context) ? $context["schema"] : (function () { throw new RuntimeError('Variable "schema" does not exist.', 47, $this->source); })()), craft\helpers\Template::attribute($this->env, $this->source, $context["props"], "nested", []), ($context["permissionName"] . "-nested"),  !(isset($context["checked"]) || array_key_exists("checked", $context) ? $context["checked"] : (function () { throw new RuntimeError('Variable "checked" does not exist.', 47, $this->source); })())], 47, $context, $this->getSourceContext());
                    echo "
                ";
                }
                // line 49
                echo "            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['permissionName'], $context['props'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "    </ul>
";
            craft\helpers\Template::endProfile("macro", "permissionList");

            return ('' === $tmp = ob_get_contents()) ? '' : new Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "graphql/schemas/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  319 => 51,  312 => 49,  306 => 47,  304 => 46,  301 => 45,  295 => 43,  293 => 42,  290 => 41,  284 => 39,  282 => 38,  278 => 36,  276 => 35,  275 => 34,  274 => 33,  273 => 31,  272 => 30,  268 => 28,  265 => 27,  262 => 26,  259 => 25,  256 => 24,  253 => 23,  249 => 22,  240 => 20,  237 => 19,  234 => 18,  232 => 17,  229 => 16,  212 => 15,  204 => 128,  202 => 127,  201 => 126,  200 => 122,  196 => 120,  194 => 119,  193 => 115,  190 => 114,  187 => 113,  182 => 112,  175 => 108,  166 => 105,  160 => 102,  157 => 101,  153 => 100,  148 => 98,  144 => 96,  135 => 93,  129 => 90,  126 => 89,  122 => 88,  119 => 87,  117 => 86,  112 => 84,  109 => 83,  103 => 79,  101 => 76,  100 => 75,  98 => 69,  96 => 68,  93 => 67,  89 => 66,  85 => 65,  80 => 64,  75 => 63,  69 => 1,  65 => 134,  63 => 133,  61 => 61,  59 => 56,  57 => 54,  55 => 13,  53 => 9,  51 => 7,  49 => 5,  44 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends \"_layouts/cp\" %}

{% requireEdition CraftPro %}

{% set selectedSubnavItem = 'schemas' %}

{% set fullPageForm = true %}

{% set crumbs = [
    { label: \"GraphQL Schemas\"|t('app'), url: url('graphql/schemas') }
] %}

{% import \"_includes/forms\" as forms %}

{% macro permissionList(schema, permissions, id, disabled) %}

    {% from \"_includes/forms\" import checkbox %}
    {% from _self import permissionList %}

    <ul{% if id %} id=\"{{ id|replace(':', '-') }}\"{% endif %}>

        {% for permissionName, props in permissions %}
            {% if schema.has(permissionName) %}
                {% set checked = true %}
            {% else %}
                {% set checked = false %}
            {% endif %}

            <li>
                {{ checkbox({
                    label: props.label,
                    name: 'permissions[]',
                    value: permissionName,
                    checked: checked,
                    disabled: disabled
                }) }}

                {% if props.info ?? false %}
                    <div class=\"info\">{{ props.info }}</div>
                {% endif %}

                {% if props.warning ?? false %}
                    <div class=\"info warning\">{{ props.warning }}</div>
                {% endif %}

                {% if props.nested ?? false %}
                    {{ permissionList(schema, props.nested, permissionName~'-nested', not checked) }}
                {% endif %}
            </li>
        {% endfor %}
    </ul>
{% endmacro %}

{% from _self import permissionList %}

{% do view.registerTranslations('app', [
    \"Select All\",
    \"Deselect All\",
]) %}

{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\userpermissions\\\\UserPermissionsAsset\") %}

{% block content %}
    {{ actionInput(schema.isPublic ? 'graphql/save-public-schema' : 'graphql/save-schema') }}
    {{ redirectInput('graphql/schemas') }}
    {% if schema.id %}{{ hiddenInput('schemaId', schema.id) }}{% endif %}

    {% if not schema.isPublic %}
        {{ forms.textField({
            first: true,
            label: \"Name\"|t('app'),
            instructions: \"What this schema will be called in the control panel.\"|t('app'),
            id: 'name',
            name: 'name',
            value: schema.name,
            errors: schema.getErrors('name'),
            autofocus: true,
            required: true
        }) }}

        <hr>
    {% endif %}

    <h2>{{ 'Choose the available content for querying with this schema:'|t('app') }}</h2>

    {% set schemaComponents = craft.app.gql.getAllSchemaComponents %}

    {% for category, catPermissions in schemaComponents.queries %}
        <div class=\"user-permissions\">
            <h3>{{ category }}</h3>
            <div class=\"select-all\"></div>

            {{ permissionList(schema, catPermissions) }}
        </div>
    {% endfor %}

    <hr/>
    <h2>{{ 'Choose the available mutations for this schema:'|t('app') }}</h2>

    {% for category, catPermissions in schemaComponents.mutations %}
        <div class=\"user-permissions\">
            <h3>{{ category }}</h3>
            <div class=\"select-all\"></div>

            {{ permissionList(schema, catPermissions) }}
        </div>
    {% endfor %}


{% endblock %}

{% block details %}
    {% if schema.isPublic %}
        <div class=\"meta\">
            {{ forms.lightswitchField({
                label: 'Enabled'|t('app'),
                id: 'enabled',
                name: 'enabled',
                on: token.enabled,
            }) }}

            {{ forms.dateTimeField({
                label: \"Expiry Date\"|t('app'),
                id: 'expiryDate',
                name: 'expiryDate',
                value: (token.expiryDate ? token.expiryDate : null),
                errors: token.getErrors('expiryDate')
            }) }}
        </div>
    {% endif %}
{% endblock %}

{% js %}
    new Craft.ElevatedSessionForm('#main-form');
{% endjs %}
", "graphql/schemas/_edit", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/graphql/schemas/_edit.twig");
    }
}
