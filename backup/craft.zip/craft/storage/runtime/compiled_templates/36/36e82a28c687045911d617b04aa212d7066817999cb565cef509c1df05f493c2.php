<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* _includes/forms/datetime */
class __TwigTemplate_b9e4ff189ebc2c2c1760cba07d0b436f84e054e553688ed4b0de30bfbbd28f68 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "_includes/forms/datetime");
        // line 1
        echo "<div class=\"datetimewrapper\">
    ";
        // line 2
        $this->loadTemplate("_includes/forms/date", "_includes/forms/datetime", 2)->display(twig_array_merge($context, ["hasOuterContainer" => true, "isDateTime" => true]));
        // line 6
        echo "    ";
        $this->loadTemplate("_includes/forms/time", "_includes/forms/datetime", 6)->display(twig_array_merge($context, ["hasOuterContainer" => true, "isDateTime" => true, "outputTzParam" => false]));
        // line 11
        echo "</div>
";
        craft\helpers\Template::endProfile("template", "_includes/forms/datetime");
    }

    public function getTemplateName()
    {
        return "_includes/forms/datetime";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 11,  43 => 6,  41 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<div class=\"datetimewrapper\">
    {% include '_includes/forms/date' with {
        hasOuterContainer: true,
        isDateTime: true,
    } %}
    {% include '_includes/forms/time' with {
        hasOuterContainer: true,
        isDateTime: true,
        outputTzParam: false,
    } %}
</div>
", "_includes/forms/datetime", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/craftcms/cms/src/templates/_includes/forms/datetime.twig");
    }
}
