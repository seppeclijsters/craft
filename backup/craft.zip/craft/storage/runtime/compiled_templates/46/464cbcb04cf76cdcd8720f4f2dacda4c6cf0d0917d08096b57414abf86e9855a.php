<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__58f3c36c6980d945b8eb20a4938088e8bc9fac50f15eec2de031df4007fec8db */
class __TwigTemplate_65f877e0feeb5736ad99a589654717d1e1df380d94d59450b273e91429f9df5d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__58f3c36c6980d945b8eb20a4938088e8bc9fac50f15eec2de031df4007fec8db");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "twitterTitle", []);
        craft\helpers\Template::endProfile("template", "__string_template__58f3c36c6980d945b8eb20a4938088e8bc9fac50f15eec2de031df4007fec8db");
    }

    public function getTemplateName()
    {
        return "__string_template__58f3c36c6980d945b8eb20a4938088e8bc9fac50f15eec2de031df4007fec8db";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.twitterTitle }}", "__string_template__58f3c36c6980d945b8eb20a4938088e8bc9fac50f15eec2de031df4007fec8db", "");
    }
}
