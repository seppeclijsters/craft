<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__31c840238d522ec35eb9bb34c7624b83c8af18ff7f8177e625ad64f8efec38cb */
class __TwigTemplate_6d9767cef8fb6df17b0e28d6d6750e9bb982837b36758f079ae006d2188ae504 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__31c840238d522ec35eb9bb34c7624b83c8af18ff7f8177e625ad64f8efec38cb");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "site", []), "identity", []), "computedType", []);
        craft\helpers\Template::endProfile("template", "__string_template__31c840238d522ec35eb9bb34c7624b83c8af18ff7f8177e625ad64f8efec38cb");
    }

    public function getTemplateName()
    {
        return "__string_template__31c840238d522ec35eb9bb34c7624b83c8af18ff7f8177e625ad64f8efec38cb";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.site.identity.computedType }}", "__string_template__31c840238d522ec35eb9bb34c7624b83c8af18ff7f8177e625ad64f8efec38cb", "");
    }
}
