<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__f01b502c84e8f13505712a71f102f7a1e1c469834d686afd9a0f10e7fc2a12d1 */
class __TwigTemplate_39fe471e9e8db6a6ac504fc1745494f689f7671eb1b68359b1f9c1868f5b5f57 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__f01b502c84e8f13505712a71f102f7a1e1c469834d686afd9a0f10e7fc2a12d1");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "ogDescription", []);
        craft\helpers\Template::endProfile("template", "__string_template__f01b502c84e8f13505712a71f102f7a1e1c469834d686afd9a0f10e7fc2a12d1");
    }

    public function getTemplateName()
    {
        return "__string_template__f01b502c84e8f13505712a71f102f7a1e1c469834d686afd9a0f10e7fc2a12d1";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.ogDescription }}", "__string_template__f01b502c84e8f13505712a71f102f7a1e1c469834d686afd9a0f10e7fc2a12d1", "");
    }
}
