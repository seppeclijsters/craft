<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__ab4de3de437dff972aa63d96b8440a10b16e516edee8710a29428f82b08ac085 */
class __TwigTemplate_c2ffbf5d7a2de9b9219707c179699f589ff3078898dc28ad61167361f87b3061 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__ab4de3de437dff972aa63d96b8440a10b16e516edee8710a29428f82b08ac085");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "seoImage", []);
        craft\helpers\Template::endProfile("template", "__string_template__ab4de3de437dff972aa63d96b8440a10b16e516edee8710a29428f82b08ac085");
    }

    public function getTemplateName()
    {
        return "__string_template__ab4de3de437dff972aa63d96b8440a10b16e516edee8710a29428f82b08ac085";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.seoImage }}", "__string_template__ab4de3de437dff972aa63d96b8440a10b16e516edee8710a29428f82b08ac085", "");
    }
}
