<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__cc14d029fb17be65839937f5ea5f02b2ad0727274a3a8c27f1ccc35a7bc1e3e7 */
class __TwigTemplate_5ada9ef27dcb169e4b94c6e19477743103e8690c24da8c03f45886a3fef07649 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__cc14d029fb17be65839937f5ea5f02b2ad0727274a3a8c27f1ccc35a7bc1e3e7");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "ogImage", []);
        craft\helpers\Template::endProfile("template", "__string_template__cc14d029fb17be65839937f5ea5f02b2ad0727274a3a8c27f1ccc35a7bc1e3e7");
    }

    public function getTemplateName()
    {
        return "__string_template__cc14d029fb17be65839937f5ea5f02b2ad0727274a3a8c27f1ccc35a7bc1e3e7";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.ogImage }}", "__string_template__cc14d029fb17be65839937f5ea5f02b2ad0727274a3a8c27f1ccc35a7bc1e3e7", "");
    }
}
