<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* seomatic/_sidebars/_includes/sidebar-preview.twig */
class __TwigTemplate_02e590552198e5a849497ae4d81e55a70956f9dfe6dba7478ccd0cb2a76695b1 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "seomatic/_sidebars/_includes/sidebar-preview.twig");
        // line 1
        craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 1, $this->source); })()), "registerAssetBundle", [0 => "nystudio107\\seomatic\\assetbundles\\seomatic\\SeomaticAsset"], "method");
        // line 2
        $context["baseAssetsUrl"] = craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new RuntimeError('Variable "view" does not exist.', 2, $this->source); })()), "getAssetManager", [], "method"), "getPublishedUrl", [0 => "@nystudio107/seomatic/assetbundles/seomatic/dist", 1 => true], "method");
        // line 3
        echo "
";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 4, $this->source); })()), "manifest", []), "registerCssModules", [0 => [0 => "vendors.css", 1 => "styles.css"]], "method"), "html", null, true);
        // line 7
        echo "

";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, (isset($context["seomatic"]) || array_key_exists("seomatic", $context) ? $context["seomatic"] : (function () { throw new RuntimeError('Variable "seomatic" does not exist.', 9, $this->source); })()), "manifest", []), "registerJsModules", [0 => [0 => "runtime.js", 1 => "vendors.js", 2 => "commons.js", 3 => "seomatic.js"]], "method"), "html", null, true);
        // line 14
        echo "

";
        // line 16
        $context["displayPreviewInlineStyles"] = "border: none; padding-left: 0;";
        // line 17
        $context["previewTypes"] = (($context["previewTypes"]) ?? ((((craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "config", [], "any", false, true), "sidebarDisplayPreviewTypes", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "config", [], "any", false, true), "sidebarDisplayPreviewTypes", [])))) ? (craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "config", [], "any", false, true), "sidebarDisplayPreviewTypes", [])) : ([0 => "google", 1 => "twitter", 2 => "facebook"]))));
        // line 18
        echo "<hr />
<div class=\"meta overflow-hidden\">
    <div class=\"data\">
        <h5 class=\"heading\">";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("SEO Preview:", "seomatic"), "html", null, true);
        echo "</h5>
    </div>
    <div style=\"zoom: 0.60; -moz-transform: scale(0.60); -moz-transform-origin: 0 0;\">
        ";
        // line 24
        if (twig_in_filter("google", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 24, $this->source); })()))) {
            // line 25
            echo "            ";
            $this->loadTemplate("seomatic/_includes/googlePreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 25)->display($context);
            // line 26
            echo "        ";
        }
        // line 27
        echo "
        ";
        // line 28
        if (twig_in_filter("twitter", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 28, $this->source); })()))) {
            // line 29
            echo "            ";
            $this->loadTemplate("seomatic/_includes/twitterPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 29)->display($context);
            // line 30
            echo "        ";
        }
        // line 31
        echo "
        ";
        // line 32
        if (twig_in_filter("facebook", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 32, $this->source); })()))) {
            // line 33
            echo "            ";
            $this->loadTemplate("seomatic/_includes/facebookPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 33)->display($context);
            // line 34
            echo "        ";
        }
        // line 35
        echo "
        ";
        // line 36
        if (twig_in_filter("linkedin", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 36, $this->source); })()))) {
            // line 37
            echo "            ";
            $this->loadTemplate("seomatic/_includes/linkedinPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 37)->display($context);
            // line 38
            echo "        ";
        }
        // line 39
        echo "
        ";
        // line 40
        if (twig_in_filter("pinterest", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 40, $this->source); })()))) {
            // line 41
            echo "            ";
            $this->loadTemplate("seomatic/_includes/pinterestPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 41)->display($context);
            // line 42
            echo "        ";
        }
        // line 43
        echo "
        ";
        // line 44
        if (twig_in_filter("slack", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 44, $this->source); })()))) {
            // line 45
            echo "            ";
            $this->loadTemplate("seomatic/_includes/slackPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 45)->display($context);
            // line 46
            echo "        ";
        }
        // line 47
        echo "
        ";
        // line 48
        if (twig_in_filter("discord", (isset($context["previewTypes"]) || array_key_exists("previewTypes", $context) ? $context["previewTypes"] : (function () { throw new RuntimeError('Variable "previewTypes" does not exist.', 48, $this->source); })()))) {
            // line 49
            echo "            ";
            $this->loadTemplate("seomatic/_includes/discordPreview.twig", "seomatic/_sidebars/_includes/sidebar-preview.twig", 49)->display($context);
            // line 50
            echo "        ";
        }
        // line 51
        echo "
    </div>
</div>
";
        craft\helpers\Template::endProfile("template", "seomatic/_sidebars/_includes/sidebar-preview.twig");
    }

    public function getTemplateName()
    {
        return "seomatic/_sidebars/_includes/sidebar-preview.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 51,  143 => 50,  140 => 49,  138 => 48,  135 => 47,  132 => 46,  129 => 45,  127 => 44,  124 => 43,  121 => 42,  118 => 41,  116 => 40,  113 => 39,  110 => 38,  107 => 37,  105 => 36,  102 => 35,  99 => 34,  96 => 33,  94 => 32,  91 => 31,  88 => 30,  85 => 29,  83 => 28,  80 => 27,  77 => 26,  74 => 25,  72 => 24,  66 => 21,  61 => 18,  59 => 17,  57 => 16,  53 => 14,  51 => 9,  47 => 7,  45 => 4,  42 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% do view.registerAssetBundle(\"nystudio107\\\\seomatic\\\\assetbundles\\\\seomatic\\\\SeomaticAsset\") %}
{% set baseAssetsUrl = view.getAssetManager().getPublishedUrl('@nystudio107/seomatic/assetbundles/seomatic/dist', true) %}

{{ seomatic.manifest.registerCssModules([
    'vendors.css',
    'styles.css',
]) }}

{{ seomatic.manifest.registerJsModules([
    'runtime.js',
    'vendors.js',
    'commons.js',
    'seomatic.js',
]) }}

{% set displayPreviewInlineStyles = \"border: none; padding-left: 0;\" %}
{% set previewTypes = previewTypes ?? seomatic.config.sidebarDisplayPreviewTypes ?? ['google', 'twitter', 'facebook'] %}
<hr />
<div class=\"meta overflow-hidden\">
    <div class=\"data\">
        <h5 class=\"heading\">{{ \"SEO Preview:\"|t('seomatic') }}</h5>
    </div>
    <div style=\"zoom: 0.60; -moz-transform: scale(0.60); -moz-transform-origin: 0 0;\">
        {% if 'google' in previewTypes %}
            {% include \"seomatic/_includes/googlePreview.twig\" %}
        {% endif %}

        {% if 'twitter' in previewTypes %}
            {% include \"seomatic/_includes/twitterPreview.twig\" %}
        {% endif %}

        {% if 'facebook' in previewTypes %}
            {% include \"seomatic/_includes/facebookPreview.twig\" %}
        {% endif %}

        {% if 'linkedin' in previewTypes %}
            {% include \"seomatic/_includes/linkedinPreview.twig\" %}
        {% endif %}

        {% if 'pinterest' in previewTypes %}
            {% include \"seomatic/_includes/pinterestPreview.twig\" %}
        {% endif %}

        {% if 'slack' in previewTypes %}
            {% include \"seomatic/_includes/slackPreview.twig\" %}
        {% endif %}

        {% if 'discord' in previewTypes %}
            {% include \"seomatic/_includes/discordPreview.twig\" %}
        {% endif %}

    </div>
</div>
", "seomatic/_sidebars/_includes/sidebar-preview.twig", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/nystudio107/craft-seomatic/src/templates/_sidebars/_includes/sidebar-preview.twig");
    }
}
