<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* typedlinkfield/_input-input */
class __TwigTemplate_8182a3a5258767a832f6a16a7de59eb6afa9c98d22334ed88048a94c2311e85d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "typedlinkfield/_input-input");
        // line 1
        $macros["forms"] = $this->macros["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_input-input", 1)->unwrap();
        // line 2
        echo "
";
        // line 3
        echo twig_call_macro($macros["forms"], "macro_text", [(isset($context["inputField"]) || array_key_exists("inputField", $context) ? $context["inputField"] : (function () { throw new RuntimeError('Variable "inputField" does not exist.', 3, $this->source); })())], 3, $context, $this->getSourceContext());
        echo "
";
        craft\helpers\Template::endProfile("template", "typedlinkfield/_input-input");
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_input-input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 3,  40 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% import \"_includes/forms\" as forms %}

{{ forms.text(inputField) }}
", "typedlinkfield/_input-input", "/Users/seppeclijsters/Documents/Appeel/craft/craft/vendor/sebastianlenz/linkfield/src/templates/_input-input.twig");
    }
}
