<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* __string_template__7e9db42c0ba77898f6add5560a4af7bd2dda35dcaad277719aa2d004152e7cb7 */
class __TwigTemplate_1ff7335996c275c6ae5821b44745c2a1512cb6e92aa2c5cc6457df6502aa872d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        craft\helpers\Template::beginProfile("template", "__string_template__7e9db42c0ba77898f6add5560a4af7bd2dda35dcaad277719aa2d004152e7cb7");
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->source, craft\helpers\Template::attribute($this->env, $this->source, ($context["seomatic"] ?? null), "meta", []), "twitterDescription", []);
        craft\helpers\Template::endProfile("template", "__string_template__7e9db42c0ba77898f6add5560a4af7bd2dda35dcaad277719aa2d004152e7cb7");
    }

    public function getTemplateName()
    {
        return "__string_template__7e9db42c0ba77898f6add5560a4af7bd2dda35dcaad277719aa2d004152e7cb7";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{{ seomatic.meta.twitterDescription }}", "__string_template__7e9db42c0ba77898f6add5560a4af7bd2dda35dcaad277719aa2d004152e7cb7", "");
    }
}
