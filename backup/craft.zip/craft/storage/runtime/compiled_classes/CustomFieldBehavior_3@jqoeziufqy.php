<?php
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Custom field behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method static headerForm(mixed $value) Sets the [[headerForm]] property
 * @method static socials(mixed $value) Sets the [[socials]] property
 * @method static jobInfo(mixed $value) Sets the [[jobInfo]] property
 * @method static details(mixed $value) Sets the [[details]] property
 * @method static snippetText(mixed $value) Sets the [[snippetText]] property
 * @method static image(mixed $value) Sets the [[image]] property
 * @method static collabs(mixed $value) Sets the [[collabs]] property
 * @method static headerImage(mixed $value) Sets the [[headerImage]] property
 * @method static showInFooterMenu(mixed $value) Sets the [[showInFooterMenu]] property
 * @method static headerBgImage(mixed $value) Sets the [[headerBgImage]] property
 * @method static footerGrid(mixed $value) Sets the [[footerGrid]] property
 * @method static showInMainMenu(mixed $value) Sets the [[showInMainMenu]] property
 * @method static address(mixed $value) Sets the [[address]] property
 * @method static seo(mixed $value) Sets the [[seo]] property
 * @method static headerSubtitle(mixed $value) Sets the [[headerSubtitle]] property
 * @method static text(mixed $value) Sets the [[text]] property
 * @method static logo(mixed $value) Sets the [[logo]] property
 * @method static headerIntro(mixed $value) Sets the [[headerIntro]] property
 * @method static showInBottomMenu(mixed $value) Sets the [[showInBottomMenu]] property
 * @method static rte(mixed $value) Sets the [[rte]] property
 * @method static linkIt(mixed $value) Sets the [[linkIt]] property
 * @method static snippetButtonText(mixed $value) Sets the [[snippetButtonText]] property
 * @method static headerButton(mixed $value) Sets the [[headerButton]] property
 * @method static gMapsUrl(mixed $value) Sets the [[gMapsUrl]] property
 * @method static website(mixed $value) Sets the [[website]] property
 * @method static snippetImage(mixed $value) Sets the [[snippetImage]] property
 * @method static headerTitle(mixed $value) Sets the [[headerTitle]] property
 * @method static contentGrid(mixed $value) Sets the [[contentGrid]] property
 * @method static words(mixed $value) Sets the [[words]] property
 * @method static direction(mixed $value) Sets the [[direction]] property
 * @method static marginBottom(mixed $value) Sets the [[marginBottom]] property
 * @method static heading(mixed $value) Sets the [[heading]] property
 * @method static services(mixed $value) Sets the [[services]] property
 * @method static blocks(mixed $value) Sets the [[blocks]] property
 * @method static bgColor(mixed $value) Sets the [[bgColor]] property
 * @method static titleSize(mixed $value) Sets the [[titleSize]] property
 * @method static companies(mixed $value) Sets the [[companies]] property
 * @method static formie(mixed $value) Sets the [[formie]] property
 * @method static images(mixed $value) Sets the [[images]] property
 * @method static quote(mixed $value) Sets the [[quote]] property
 * @method static bgBlack(mixed $value) Sets the [[bgBlack]] property
 * @method static position(mixed $value) Sets the [[position]] property
 * @method static jobs(mixed $value) Sets the [[jobs]] property
 * @method static button(mixed $value) Sets the [[button]] property
 * @method static offices(mixed $value) Sets the [[offices]] property
 * @method static profileUrl(mixed $value) Sets the [[profileUrl]] property
 * @method static platform(mixed $value) Sets the [[platform]] property
 * @method static word(mixed $value) Sets the [[word]] property
 * @method static intro(mixed $value) Sets the [[intro]] property
 * @method static skills(mixed $value) Sets the [[skills]] property
 * @method static skillLevel(mixed $value) Sets the [[skillLevel]] property
 * @method static skillName(mixed $value) Sets the [[skillName]] property
 */
class CustomFieldBehavior extends Behavior
{
    /**
     * @var bool Whether the behavior should provide methods based on the field handles.
     */
    public bool $hasMethods = false;

    /**
     * @var bool Whether properties on the class should be settable directly.
     */
    public bool $canSetProperties = true;

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'headerForm' => true,
        'socials' => true,
        'jobInfo' => true,
        'details' => true,
        'snippetText' => true,
        'image' => true,
        'collabs' => true,
        'headerImage' => true,
        'showInFooterMenu' => true,
        'headerBgImage' => true,
        'footerGrid' => true,
        'showInMainMenu' => true,
        'address' => true,
        'seo' => true,
        'headerSubtitle' => true,
        'text' => true,
        'logo' => true,
        'headerIntro' => true,
        'showInBottomMenu' => true,
        'rte' => true,
        'linkIt' => true,
        'snippetButtonText' => true,
        'headerButton' => true,
        'gMapsUrl' => true,
        'website' => true,
        'snippetImage' => true,
        'headerTitle' => true,
        'contentGrid' => true,
        'words' => true,
        'direction' => true,
        'marginBottom' => true,
        'heading' => true,
        'services' => true,
        'blocks' => true,
        'bgColor' => true,
        'titleSize' => true,
        'companies' => true,
        'formie' => true,
        'images' => true,
        'quote' => true,
        'bgBlack' => true,
        'position' => true,
        'jobs' => true,
        'button' => true,
        'offices' => true,
        'profileUrl' => true,
        'platform' => true,
        'word' => true,
        'intro' => true,
        'skills' => true,
        'skillLevel' => true,
        'skillName' => true,
    ];

    /**
     * @var \verbb\formie\elements\db\FormQuery Value for field with the handle “headerForm”.
     */
    public $headerForm;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “socials”.
     */
    public $socials;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “jobInfo”.
     */
    public $jobInfo;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “details”.
     */
    public $details;

    /**
     * @var mixed Value for field with the handle “snippetText”.
     */
    public $snippetText;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery|\craft\elements\db\EntryQuery Value for field with the handle “collabs”.
     */
    public $collabs;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “headerImage”.
     */
    public $headerImage;

    /**
     * @var bool Value for field with the handle “showInFooterMenu”.
     */
    public $showInFooterMenu;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “headerBgImage”.
     */
    public $headerBgImage;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “footerGrid”.
     */
    public $footerGrid;

    /**
     * @var bool Value for field with the handle “showInMainMenu”.
     */
    public $showInMainMenu;

    /**
     * @var mixed Value for field with the handle “address”.
     */
    public $address;

    /**
     * @var mixed Value for field with the handle “seo”.
     */
    public $seo;

    /**
     * @var string|null Value for field with the handle “headerSubtitle”.
     */
    public $headerSubtitle;

    /**
     * @var string|null|mixed Value for field with the handle “text”.
     */
    public $text;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “logo”.
     */
    public $logo;

    /**
     * @var mixed Value for field with the handle “headerIntro”.
     */
    public $headerIntro;

    /**
     * @var bool Value for field with the handle “showInBottomMenu”.
     */
    public $showInBottomMenu;

    /**
     * @var mixed Value for field with the handle “rte”.
     */
    public $rte;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “linkIt”.
     */
    public $linkIt;

    /**
     * @var string|null Value for field with the handle “snippetButtonText”.
     */
    public $snippetButtonText;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “headerButton”.
     */
    public $headerButton;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “gMapsUrl”.
     */
    public $gMapsUrl;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “website”.
     */
    public $website;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “snippetImage”.
     */
    public $snippetImage;

    /**
     * @var string|null Value for field with the handle “headerTitle”.
     */
    public $headerTitle;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “contentGrid”.
     */
    public $contentGrid;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “words”.
     */
    public $words;

    /**
     * @var \craft\fields\data\SingleOptionFieldData Value for field with the handle “direction”.
     */
    public $direction;

    /**
     * @var bool Value for field with the handle “marginBottom”.
     */
    public $marginBottom;

    /**
     * @var mixed|string|null Value for field with the handle “heading”.
     */
    public $heading;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “services”.
     */
    public $services;

    /**
     * @var \verbb\supertable\elements\db\SuperTableBlockQuery Value for field with the handle “blocks”.
     */
    public $blocks;

    /**
     * @var bool Value for field with the handle “bgColor”.
     */
    public $bgColor;

    /**
     * @var bool Value for field with the handle “titleSize”.
     */
    public $titleSize;

    /**
     * @var \craft\elements\db\EntryQuery Value for field with the handle “companies”.
     */
    public $companies;

    /**
     * @var \verbb\formie\elements\db\FormQuery Value for field with the handle “formie”.
     */
    public $formie;

    /**
     * @var \craft\elements\db\AssetQuery Value for field with the handle “images”.
     */
    public $images;

    /**
     * @var mixed Value for field with the handle “quote”.
     */
    public $quote;

    /**
     * @var bool Value for field with the handle “bgBlack”.
     */
    public $bgBlack;

    /**
     * @var mixed Value for field with the handle “position”.
     */
    public $position;

    /**
     * @var \craft\elements\db\EntryQuery Value for field with the handle “jobs”.
     */
    public $jobs;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “button”.
     */
    public $button;

    /**
     * @var \craft\elements\db\EntryQuery Value for field with the handle “offices”.
     */
    public $offices;

    /**
     * @var \lenz\linkfield\models\Link Value for field with the handle “profileUrl”.
     */
    public $profileUrl;

    /**
     * @var string|null Value for field with the handle “platform”.
     */
    public $platform;

    /**
     * @var string|null Value for field with the handle “word”.
     */
    public $word;

    /**
     * @var mixed Value for field with the handle “intro”.
     */
    public $intro;

    /**
     * @var \craft\elements\db\MatrixBlockQuery Value for field with the handle “skills”.
     */
    public $skills;

    /**
     * @var \craft\fields\data\SingleOptionFieldData Value for field with the handle “skillLevel”.
     */
    public $skillLevel;

    /**
     * @var string|null Value for field with the handle “skillName”.
     */
    public $skillName;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private array $_customFieldValues = [];

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name): bool
    {
        if ($this->hasMethods && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }

    /**
     * @inheritdoc
     */
    public function __isset($name): bool
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true): bool
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true): bool
    {
        if (!$this->canSetProperties) {
            return false;
        }
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
