/*!
 * @project        seomatic
 * @name           seomatic.js
 * @author         Andrew Welch
 * @build          Mon Oct 03 2022 20:23:21 GMT+0000 (Coordinated Universal Time)
 * @copyright      Copyright (c) 2022 ©2020 nystudio107.com
 *
 */
"use strict";(self.webpackChunkseomatic=self.webpackChunkseomatic||[]).push([[487],{5204:function(n,c,e){e.p,e.p,e.p}},function(n){n.O(0,[532],(function(){return c=5204,n(n.s=c);var c}));n.O()}]);
//# sourceMappingURL=seomatic.js.map