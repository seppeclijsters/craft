/*!
 * @project        seomatic
 * @name           seomatic.js
 * @author         Andrew Welch
 * @build          Wed Jun 22 2022 03:12:58 GMT+0000 (Coordinated Universal Time)
 * @copyright      Copyright (c) 2022 ©2020 nystudio107.com
 *
 */
"use strict";(self.webpackChunkseomatic=self.webpackChunkseomatic||[]).push([[487],{4747:function(n,c,e){e.p,e.p,e.p}},function(n){n.O(0,[532],(function(){return c=4747,n(n.s=c);var c}));n.O()}]);
//# sourceMappingURL=seomatic.js.map